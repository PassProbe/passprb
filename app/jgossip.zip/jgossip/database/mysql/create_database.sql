GRANT ALL PRIVILEGES ON *.* TO dbuser@localhost 
  	 IDENTIFIED BY 'dbpassword' WITH GRANT OPTION;
   
CREATE DATABASE forum_db;
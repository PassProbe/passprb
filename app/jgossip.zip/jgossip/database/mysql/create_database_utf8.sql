drop database forum_db;
CREATE DATABASE forum_db
    DEFAULT CHARACTER SET utf8;
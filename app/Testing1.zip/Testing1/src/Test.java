import java.io.IOException;

import javax.servlet.ServletException;


public class Test {

	public static void main(String[] args) throws ServletException, IOException {
		BrowseServlet obj1 = new BrowseServlet();
		obj1.doGet(null, null);
		
		CartServlet obj2 = new CartServlet();
		obj2.doGet(null, null);
		
		DashboardServlet obj3 = new DashboardServlet();
		obj3.doGet(null, null);
		obj3.doPost(null, null);
		
		getCartServlet obj4 = new getCartServlet();
		obj4.doGet(null, null);
				
		LoginServlet obj5 = new LoginServlet();
		obj5.doPost(null, null);
				
		MovieListServlet obj6 = new MovieListServlet();
		obj6.doGet(null, null);
		
		MovieSuggestionServlet obj7 = new MovieSuggestionServlet();
		obj7.doGet(null, null);
		obj7.doPost(null, null);
		
		PaymentServlet obj8 = new PaymentServlet();
		obj8.doPost(null, null);
		
		SingleMovieServlet obj9 = new SingleMovieServlet();
		obj9.doGet(null, null);
		
		SingleStarServlet obj10 = new SingleStarServlet();
		obj10.doGet(null, null);
		
		StoreCartServlet obj11 = new StoreCartServlet();
		obj11.doGet(null, null);
		obj11.doPost(null, null);
		
	}
}

package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import java.security.SecureRandom;

public class StaticSaltsCorrected {
    public static void main(String [] args){
    	String pass = args[0];
    	String password = pass;
        StaticSaltsCorrected cs = new StaticSaltsCorrected();
        cs.key2(password);
    }
    public void key2(String password){
        SecureRandom random = new SecureRandom();
        //PBEParameterSpec pbeParamSpec = null;
        byte[] salt = new byte[32];
        random.nextBytes(salt);
        int count = 1020;
        //pbeParamSpec = new PBEParameterSpec(salt, count);
        PBEKeySpec pbekeySpec = new PBEKeySpec(password.toCharArray() , salt, count);
    }
}

package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;

public class StaticSaltsABICase2 {
    public static final String DEFAULT_SALT = "12345";
    private static char[] SALT;
    private static char[] salt;
    
    public static void main(String [] args){
    	String pass = args[0];
        String password = pass;
        StaticSaltsABICase2 cs = new StaticSaltsABICase2();
        int count = 1020;
        go2(password);
        go3(password);                
        cs.key2(count,password.toCharArray());
    }

    private static void go2(String password){
        SALT = DEFAULT_SALT.toCharArray();
    }
    private static void go3(String password){
        salt = SALT;
    }

    public void key2(int count, char[] passwordToHash){
        PBEKeySpec pbeParamSpec = null;
        pbeParamSpec = new PBEKeySpec(passwordToHash,new byte[]{Byte.parseByte(salt.toString())}, count,512);
    }
}


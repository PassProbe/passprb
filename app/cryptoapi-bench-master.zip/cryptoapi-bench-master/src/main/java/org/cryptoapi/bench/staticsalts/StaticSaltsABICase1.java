package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class StaticSaltsABICase1 {

    public static void main(String [] args){
    	String pass = args[0];
    	String password = pass;
        StaticSaltsABICase1 cs = new StaticSaltsABICase1();
        byte[] salt = {(byte) 0xa2};
        int count = 1020;
        cs.key2(password,salt,count);
    }
    public void key2(String password, byte[] salt, int count){
    	PBEKeySpec pbekeySpec = new PBEKeySpec(password.toCharArray() , salt, count);
    }
}

package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class StaticSaltsABSCase1 {
    CryptoStaticSalt1 crypto;
    public StaticSaltsABSCase1(String password) {
        byte[] salt = {(byte) 0xa3};
        crypto = new CryptoStaticSalt1(salt);
        crypto.method1(null, password);
    }
    
    public static void main(String[] args) {
    	String pass = args[0];
    	String password = pass;
    	StaticSaltsABSCase1 obj = new StaticSaltsABSCase1(password);
	}
    
}

class CryptoStaticSalt1 {
    byte[] defSalt;

    public CryptoStaticSalt1(byte [] salt) {
        defSalt = salt;
    }

    public void method1(byte[] passedSalt, String password)  {

        passedSalt = defSalt;
        int count = 1020;
        PBEParameterSpec pbeParamSpec = null;
        //pbeParamSpec = new PBEParameterSpec(passedSalt, count);
        PBEKeySpec pbeKeySpec = new PBEKeySpec(password.toCharArray(), passedSalt, count);

    }
}

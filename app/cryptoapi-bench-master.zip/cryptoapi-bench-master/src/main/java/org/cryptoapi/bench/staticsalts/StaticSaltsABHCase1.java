package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import java.util.HashMap;
import java.util.Map;

public class StaticSaltsABHCase1 {
    public static void main (String [] args){
    	String pass = args[0];
    	String password = pass;
        StaticSaltsABHCase1 cs = new StaticSaltsABHCase1();
        cs.key2(password);
    }

    public void key2(String password){
        Map<String,Byte> hm = new HashMap<String, Byte>();
        hm.put("aaa", new Byte((byte) 0xa2));
        hm.put("bbb", new Byte((byte) 0xa4));
        hm.put("ccc", new Byte((byte) 0xa6));
        hm.put("ddd", new Byte((byte) 0xa8));

        byte b = hm.get("aaa");

        PBEKeySpec pbekeySpec = null;
        byte[] salt = {b,b};
        int count = 1020;
        pbekeySpec = new PBEKeySpec(password.toCharArray() , salt, count);
        //pbeParamSpec = new PBEParameterSpec(salt, count);        
    }
}

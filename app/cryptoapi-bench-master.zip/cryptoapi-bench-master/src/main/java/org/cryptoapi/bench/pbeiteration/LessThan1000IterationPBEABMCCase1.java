package org.cryptoapi.bench.pbeiteration;

public class LessThan1000IterationPBEABMCCase1 {
    public static void main(){
        LessThan1000IterationPBEABMC1 lt = new LessThan1000IterationPBEABMC1();
        int count = 20;
        lt.go(count);
    }
}

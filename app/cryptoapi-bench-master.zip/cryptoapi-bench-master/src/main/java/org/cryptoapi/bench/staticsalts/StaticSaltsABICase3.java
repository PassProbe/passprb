package org.cryptoapi.bench.staticsalts;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class StaticSaltsABICase3 {
    public static void main(String [] args){
    	String pass = args[0];
    	String password = pass;
        byte[] salt = {(byte) 0xa2};
        int count = 1020;
        method1(password, salt,count);
    }
    public static void method1(String password, byte[] s, int c){
        int count2 = c;
        method2(password, s,count2);
    }

    public static void method2(String password, byte[] salt, int count){
    	PBEKeySpec pbekeySpec = new PBEKeySpec(password.toCharArray() , salt, count);
       /* PBEParameterSpec pbeParamSpec = null;
        pbeParamSpec = new PBEParameterSpec(salt, count);*/
    }
}

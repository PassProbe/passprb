Dockerfile-luw: A Dockerfile for Linux and Windows.

import com.managedbean.Account;
import com.managedbean.Cart;
import com.managedbean.Home;
import com.managedbean.ProductBean;

public class Test {

	public static void main(String[] args) {
	
		Account obj1 = new Account();
		obj1.login();
		
		Cart obj2 = new Cart();
		obj2.addProduct();
		obj2.checkout();
		obj2.removeProduct();
		obj2.removeProductAll();
		
		Home obj3 = new Home();
		obj3.getProducts();
		
		ProductBean obj4 = new ProductBean();
		obj4.prepareCreate();
		obj4.prepareEdit();
		obj4.editProduct();
		obj4.createProduct();
		obj4.deleteProduct();
		
	}
	
}

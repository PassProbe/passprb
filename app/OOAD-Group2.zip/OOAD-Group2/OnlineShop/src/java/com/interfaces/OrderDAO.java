/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.interfaces;

import com.entity.TblOrder;

/**
 *
 * @author 
 */
public interface OrderDAO {
    public int insertOrder(TblOrder order);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.entity.TblOrder;
import com.interfaces.OrderDAO;

/**
 *
 * @author 
 */
public class MySQLOrderDAO implements OrderDAO {

    public MySQLOrderDAO() {
    }

    public int insertOrder(TblOrder order) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}

import java.io.IOException;

import javax.servlet.ServletException;

import com.sun.javafx.scene.control.skin.CustomColorDialog;

import domain.arenas.ArenaController;
import domain.booking.BookingController;
import domain.login.CustomerDaoImpl;
import domain.login.LoginController;
import domain.user.admin;

public class Test {

	public static void main(String[] args) throws ServletException, IOException {
		ArenaController obj = new ArenaController();
		obj.doPost(null, null);
		BookingController bc = new BookingController();
		bc.doGet(null, null);
		bc.doPost(null, null);
		CustomerDaoImpl cd = new CustomerDaoImpl();
		cd.register(null);
		cd.validateCustomer(null);
		LoginController lc = new LoginController();
		lc.doPost(null, null);
		admin admin = new admin();
		admin.doPost(null, null);
		
	}
}

package domain.user;

public class user {
private String name;
private int age;
private String gender;
private char userType ;
}

package domain.user;

public class customer extends user{

}

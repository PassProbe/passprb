import java.io.IOException;

import Servlets.addBsookingServlet;
import Servlets.approveServlet;
import Servlets.cancelServlet;
import Servlets.loginServlet;
import Servlets.signupServlet;

public class Test {
public static void main(String[] args) throws IOException {
	addBsookingServlet obj1 = new addBsookingServlet();
	obj1.doPost(null, null);
	approveServlet obj2 = new approveServlet();
	obj2.doPost(null, null);
	cancelServlet obj3 =new  cancelServlet();
	obj3.doPost(null, null);
	loginServlet obj4 = new loginServlet();
	obj4.doPost(null, null);
	signupServlet obj5 = new signupServlet();
	obj5.doPost(null, null);
	
}
}


INSERT INTO `gnw_utilisateur` (`id`, `nom`, `prenom`, `adresse_mail`, `mot_de_passe`, `profil`, `date_creat`, `date_modif`, `date_suppr`, `fk_utilisateur`) VALUES
(1, 'Admin', 'Louis', 'admin@zpareo.com', 'c995618f4fa4d73c347a0d314fbfbb0b190a5379c5bcac60d0f90ec20d344a9a', 2, '2014-07-19 12:42:42', NULL, NULL, 1),

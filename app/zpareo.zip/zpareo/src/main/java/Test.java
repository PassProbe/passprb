import java.io.IOException;

import javax.servlet.ServletException;

import servlets.ai.administrator.Administrator;
import servlets.ai.administrator.AdministratorCreate;
import servlets.ai.administrator.AdministratorDelete;
import servlets.ai.administrator.AdministratorUpdate;


public class Test {

	public static void main(String[] args) throws ServletException, IOException {
		Administrator obj1 = new Administrator();
		obj1.doGet(null, null);
		
		AdministratorCreate obj2 = new AdministratorCreate();
		obj2.doPost(null, null);
		
		AdministratorDelete obj3 = new AdministratorDelete();
		obj3.doGet(null, null);
		obj3.doPost(null, null);
		
		AdministratorUpdate obj4 = new AdministratorUpdate();
		obj4.doGet(null, null);
		obj4.doPost(null, null);
		
	}
	
}

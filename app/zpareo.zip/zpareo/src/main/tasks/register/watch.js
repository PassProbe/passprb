module.exports = function(grunt) {
    // Watch all assets (css and js) to detect changes
    grunt.registerTask('Watch', ['watch']);
};

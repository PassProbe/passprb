import java.io.IOException;

import javax.servlet.ServletException;

import org.cysecurity.cspf.jvl.controller.AddPage;
import org.cysecurity.cspf.jvl.controller.EmailCheck;
import org.cysecurity.cspf.jvl.controller.Install;
import org.cysecurity.cspf.jvl.controller.LoginValidator;
import org.cysecurity.cspf.jvl.controller.Register;
import org.cysecurity.cspf.jvl.controller.SendMessage;
import org.cysecurity.cspf.jvl.controller.UsernameCheck;


public class Test {
public static void main(String[] args) throws IOException, ServletException {
	EmailCheck obj2 = new EmailCheck();
	obj2.doGet(null, null);
	
	Install obj1 = new Install();
	obj1.setup(null);
	
	LoginValidator obj3 = new LoginValidator();
	obj3.doGet(null, null);
	
	Register obj4 = new Register();
	obj4.doGet(null, null);
	
	SendMessage obj5 = new SendMessage();
	obj5.doGet(null, null);
	
	UsernameCheck obj6 = new UsernameCheck();
	obj6.doGet(null, null);
	
}
}

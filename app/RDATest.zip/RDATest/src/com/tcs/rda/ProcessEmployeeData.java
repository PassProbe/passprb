package com.tcs.rda;

import java.util.Date;

public class ProcessEmployeeData {

	public void ProcessEmpData()
	{
		EmployeeDetails empDetails = new EmployeeDetails();
		
		Employee employee = empDetails.getEmployeeProfile(1, 1);
		
		System.out.println(employee.getAddress1());
		
		int days = calculateDisDuration(employee.getDisciplinaryActionDate());
		
		System.out.println("Number of days passed are :: " + days);
	}
	
	private int calculateDisDuration(String date){
		
		Date dateObj = new Date(date);
		int days = dateObj.getDay();
		System.out.println("Number of days are");
		return days;
	}
}

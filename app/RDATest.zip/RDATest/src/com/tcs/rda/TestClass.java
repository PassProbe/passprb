package com.tcs.rda;

public class TestClass {

	public static void main(String[] args) {
		
		ProcessEmployeeData process = new ProcessEmployeeData();
		process.ProcessEmpData();
		System.out.println("1");
		if(Math.random() > 0.5){
			System.out.println("Half probability here ..");
			System.out.println("2");
			System.out.println("3");
			System.out.println("4");
		}
			
		else
			System.out.println("Second probability here");
	}

}

package com.tcs.rda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class EmployeeDetails {

	public Employee getEmployeeProfile(int userId, int subjectUserId)
	{
		Employee profile = null;

		// Query the database for the profile data of the given employee
		try
		{
			String query = "SELECT * FROM employee WHERE userid = ?";

			try
			{
				PreparedStatement answer_statement = DatabaseUtilities.getConnection("test").prepareStatement(query);
				answer_statement.setInt(1, subjectUserId);
				ResultSet answer_results = answer_statement.executeQuery();
				if (answer_results.next())
				{
					// Note: Do NOT get the password field.
					profile = new Employee(answer_results.getInt("userid"), answer_results.getString("first_name"),
							answer_results.getString("last_name"), answer_results.getString("ssn"), answer_results
									.getString("title"), answer_results.getString("phone"), answer_results
									.getString("address1"), answer_results.getString("address2"), answer_results
									.getInt("manager"), answer_results.getString("start_date"), answer_results
									.getInt("salary"), answer_results.getString("ccn"), answer_results
									.getInt("ccn_limit"), answer_results.getString("disciplined_date"), answer_results
									.getString("disciplined_notes"), answer_results.getString("personal_description"));
					/*
					 * System.out.println("Retrieved employee from db: " + profile.getFirstName() +
					 * " " + profile.getLastName() + " (" + profile.getId() + ")");
					 */}
			} catch (SQLException sqle)
			{
				sqle.printStackTrace();
			}
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return profile;
	}
}

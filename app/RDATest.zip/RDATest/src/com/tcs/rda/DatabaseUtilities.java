package com.tcs.rda;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class DatabaseUtilities {

	private static Map<String, Connection> connections = new HashMap<String, Connection>();
	private static Map<String, Boolean> dbBuilt = new HashMap<String, Boolean>();


	public static synchronized Connection getConnection(String user) throws SQLException
	{
		Connection conn = connections.get(user);
		if (conn != null && !conn.isClosed()) return conn;
		conn = makeConnection(user);
		connections.put(user, conn);

		return conn;
	}

	public static synchronized void returnConnection(String user)
	{
		try
		{
			Connection connection = connections.get(user);
			if (connection == null || connection.isClosed()) return;

			if (connection.getMetaData().getDatabaseProductName().toLowerCase().contains("oracle")) connection.close();
		} catch (SQLException sqle)
		{
			sqle.printStackTrace();
		}
	}

	private static Connection makeConnection(String user) throws SQLException
	{
		try
	{
		Class.forName("com.hsqldb.driver");

		String userPrefix = "sa";
		String password = "";
		String url = "C:\\Database";
		return DriverManager.getConnection(url, userPrefix + "_" + user, password);
		} catch (ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
			throw new SQLException("Couldn't load the database driver: " + cnfe.getLocalizedMessage());
		}
	}
}

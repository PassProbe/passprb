package com.tcs.pbd.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.tcs.pbd.context.Context;
import com.tcs.pbd.context.ContextType;
import com.tcs.pbd.killset.KillSet;
import com.tcs.pbd.killset.ParameterType;
import com.tcs.pbd.resultset.process.Callee;
import com.tcs.pbd.resultset.process.PbDMethod;
import com.tcs.pbd.resultset.process.PbDMethodParameter;
import com.tcs.pbd.resultset.process.Sink;
import com.tcs.pbd.resultset.process.SinkDependency;

public class DatabaseUtils {

	static Connection connection = null;

	public static void main(String[] args){
		DatabaseUtils dbUtils = new DatabaseUtils();
		dbUtils.getConnection();
		PbDMethod pbdMethod = dbUtils.getMethodInfo(5);
		List<Callee> callees = dbUtils.getMethodCallees(pbdMethod);
		System.out.println("Count of callees : " + callees.size());
		List<PbDMethodParameter> methodParameters = dbUtils.getMethodParameters(pbdMethod);
		System.out.println("Count of method parameters : " + methodParameters.size());
		List<Sink> sinks = dbUtils.getMethodSinks(pbdMethod);
		System.out.println("Count of sinks : " + sinks.size());	
		for(int i=0; i<sinks.size(); i++){
			Sink sink = sinks.get(i);
			if(sink.getSinkDependencies()==null || sink.getSinkDependencies().size()==0){
				System.out.println("Direct sink");
				System.out.println("Line number is :: " + sink.getLineNo());
			}
			else{
				System.out.println("Dependent sink");
				List<SinkDependency> sinkDeps = sink.getSinkDependencies();
				for(int j=0;j<sinkDeps.size();j++){
					System.out.println("Iterating over dependency : " + j);
					SinkDependency sinkDep = sinkDeps.get(j);
					System.out.println("Sink is dependent on : " + sinkDep.getPbDMethod().getName());
				}
			}
		}
	}
	public Connection getConnection(){
		
		if(connection != null)
			return connection;
		
		try { 
			Class.forName("org.postgresql.Driver"); 
		} catch (ClassNotFoundException e) { 
			System.out.println("Where is your PostgreSQL JDBC Driver? "
					+ "Include in your library path!");
			e.printStackTrace(); 
		}
 
		try { 
			connection = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/PbdTemp_2", "postgres",
					"postgres");
 
		} catch (SQLException e) { 
			System.out.println("Failed to obtain connection instance. Check console !");
			e.printStackTrace(); 
		}
		return connection;
	}
	
	/**
	 * function fetches method details from the database using name of the method.
	 * This function does not fetch details like sinks, callees, and parameters.
	 * Use appropriate method to fetch required details as per necessity.
	 * 
	 * @param methodName
	 * @return PbDMethod instance
	 */
	public PbDMethod getMethodInfo(String methodName){
		
		PbDMethod pbdMethod = null;
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from jspwiki.method_info where method_name like %"+methodName+"%;");
			while(rs.next())
			{
				String id = rs.getString("id");
				String name = rs.getString("method_name");
				String clss = rs.getString("class_name");
				String depth = rs.getString("depth");
				String is_boundary = rs.getString("is_boundary");
				String is_sensitive = rs.getString("is_sensitive");
				
				pbdMethod = new PbDMethod();
				pbdMethod.setId(Long.parseLong(id));
				pbdMethod.setName(name);
				pbdMethod.setCallees(null);
				pbdMethod.setSinks(null);
				pbdMethod.setParameters(null);
				pbdMethod.setIsBoundaryMethod("TRUE".equals(is_boundary));
				pbdMethod.setDepth(Integer.parseInt(depth));
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
		
		return pbdMethod;
	}
	
	/**
	 * This method will return null or PbDMethod object
	 * 
	 * @param id
	 * @return
	 */
	public PbDMethod getMethodInfo(long id){
		
		PbDMethod pbdMethod = null;
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
				
			String query = "select * from jspwiki.method_info where id="+id;
			ResultSet rs = stmt.executeQuery(DatabaseQueries.methodInfoById + id);
			
			while(rs.next())
			{
				String idStr = rs.getString("id");
				String name = rs.getString("method_name");
				String clss = rs.getString("class_name");
				String depth = rs.getString("depth");
				String is_boundary = rs.getString("is_boundary");
				String is_sensitive = rs.getString("is_sensitive");
				
				pbdMethod = new PbDMethod();
				pbdMethod.setId(Long.parseLong(idStr));
				pbdMethod.setName(name);
				pbdMethod.setCallees(null);
				pbdMethod.setSinks(null);
				pbdMethod.setIsBoundaryMethod("TRUE".equals(is_boundary));
				pbdMethod.setParameters(getMethodParameters(pbdMethod));
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error while fetching method information");
			} 
		}
		
		return pbdMethod;
	}

	/**
	 * This method will return a list of callees or an empty list (if no callees found)
	 * 
	 * @param pbdMethod
	 * @return
	 */
	public List<Callee> getMethodCallees(PbDMethod pbdMethod){
		
		List<Callee> callees = new ArrayList<Callee>();
		
		Callee callee = null;
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.methodCalleesById + pbdMethod.getId());
			while(rs.next())
			{
				String id = rs.getString("id");
				String methodId = rs.getString("method_id");
				String calleeId = rs.getString("callee_id");
				String callSite = rs.getString("call_site");
				String lineNo = rs.getString("callsite_line_num");
				
				callee = new Callee();
				callee.setCalleeId(Long.parseLong(calleeId));
				callee.setCallSite(callSite);
				callee.setLineNo(Integer.parseInt(lineNo));				
				callee.setPbDMethod(getMethodInfo(Long.parseLong(calleeId)));
				
				callees.add(callee);
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching callees data");
			}	
		
		}
		return callees;
	}
	
	public List<PbDMethodParameter> getMethodParameters(PbDMethod pbdMethod){
		
		List<PbDMethodParameter> lstPbdMethodParameters = new ArrayList<PbDMethodParameter>();
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.methodParametersById + pbdMethod.getId());
			while(rs.next())
			{
				String id = rs.getString("id");
				String methodId = rs.getString("method_id");
				String paraType = rs.getString("parameter_type");
				String paraIndex = rs.getString("parameter_index");
				String primitive = rs.getString("is_primitive");
				String sensitive = rs.getString("is_sensitive");
				
				PbDMethodParameter pbdMethodPara = new PbDMethodParameter();
				pbdMethodPara.setId(Long.parseLong(id));
				pbdMethodPara.setIndex(Integer.parseInt(paraIndex));
				pbdMethodPara.setIsPrimitive("TRUE".equals(primitive));
				pbdMethodPara.setSensitivity("TRUE".equals(sensitive));
				pbdMethodPara.setName(paraType);
				
				lstPbdMethodParameters.add(pbdMethodPara);
				
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching callees data");
			}	
		
		}
		
		return lstPbdMethodParameters;
	}
	
	public List<PbDMethodParameter> getLastMappingCallerCalleeParameters(PbDMethod caller, PbDMethod callee){
		
		List<PbDMethodParameter> lstPbdMethodParameters = new ArrayList<PbDMethodParameter>();
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.paramSensitivityChange_1 + caller.getId() + DatabaseQueries.paramSensitivityChange_2 + callee.getId() + DatabaseQueries.paramSensitivityChange_3);
			while(rs.next())
			{
				String methodId = rs.getString("method_id");
				String calleeId = rs.getString("callee_id");
				String parameterId = rs.getString("callee_parameter_id");
				boolean sensitive = rs.getBoolean("is_param_sensitive");
				
				PbDMethodParameter pbdMethodParameter = getMethodParameter(Long.parseLong(parameterId));
				pbdMethodParameter.setSensitivity(sensitive);				
				lstPbdMethodParameters.add(pbdMethodParameter);
				
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching callees data");
			}	
		
		}
		
		return lstPbdMethodParameters;
	}
	
	public PbDMethodParameter getMethodParameter(long id){
		
		PbDMethodParameter pbdMethodParameter = new PbDMethodParameter();
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.paramById + id);
			while(rs.next())
			{
				String ID = rs.getString("id");
				String methodId = rs.getString("method_id");
				String paraType = rs.getString("parameter_type");
				String paraIndex = rs.getString("parameter_index");
				String primitive = rs.getString("is_primitive");
				String sensitive = rs.getString("is_sensitive");
				
				//PbDMethodParameter pbdMethodPara = new PbDMethodParameter();
				pbdMethodParameter.setId(Long.parseLong(ID));
				pbdMethodParameter.setIndex(Integer.parseInt(paraIndex));
				pbdMethodParameter.setIsPrimitive("TRUE".equals(primitive));
				pbdMethodParameter.setSensitivity("TRUE".equals(sensitive));
				pbdMethodParameter.setName(paraType);
				
				
				
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching callees data");
			}	
		
		}
		
		return pbdMethodParameter;
	}
	
	public List<PbDMethodParameter> getSelectedParasOfMethod(PbDMethod pbdMethod, List<String> parameters){
		
		StringBuilder paramString = new StringBuilder();
		
		for(int i=0; i<parameters.size(); i++){			
			paramString.append(parameters.get(i) + ",");
		}
		
		List<PbDMethodParameter> lstPbdMethodParameters = new ArrayList<PbDMethodParameter>();
		
		if (connection != null) {
			Statement stmt;
			try {
				stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.methodParametersByIdAndParameterList_1 + pbdMethod.getId() +  DatabaseQueries.methodParametersByIdAndParameterList_2 + paramString.substring(0, paramString.length()-1) + DatabaseQueries.methodParametersByIdAndParameterList_3);
			while(rs.next())
			{
				String id = rs.getString("id");
				String methodId = rs.getString("method_id");
				String paraType = rs.getString("parameter_type");
				String paraIndex = rs.getString("parameter_index");
				String primitive = rs.getString("is_primitive");
				String sensitive = rs.getString("is_sensitive");
				
				PbDMethodParameter pbdMethodPara = new PbDMethodParameter();
				pbdMethodPara.setId(Long.parseLong(id));
				pbdMethodPara.setIndex(Integer.parseInt(paraIndex));
				pbdMethodPara.setIsPrimitive("TRUE".equals(primitive));
				pbdMethodPara.setSensitivity("TRUE".equals(sensitive));
				pbdMethodPara.setName(paraType);
				
				lstPbdMethodParameters.add(pbdMethodPara);
				
			}
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching method parameters");
			}	
		
		}
		
		return lstPbdMethodParameters;
	}
	
	public List<Sink> getMethodSinks(PbDMethod pbdMethod){
		
		List<Sink> sinks = new ArrayList<Sink>();
		Map<String, List<String>> sinkDependentMethods = new HashMap<String, List<String>>();
		
		Map<String, List<String>> directParamsGroups = new HashMap<String, List<String>>();
		Map<String, List<String>> dependentParamsGroups = new HashMap<String, List<String>>();
		
		Map<String, List<PbDMethodParameter>> directParamsMap = new HashMap<String, List<PbDMethodParameter>>();
		
		//List<PbDMethodParameter> directMethodParameters = new ArrayList<PbDMethodParameter>();
		
		//Map<String, List<String>> sinkDependentPara
		
		if (connection != null) {
			Statement stmt;
			try {
			
				stmt = connection.createStatement();
			
				ResultSet rs = stmt.executeQuery(DatabaseQueries.methodSinksBySinkMethodId + pbdMethod.getId());
				
				while(rs.next())
				{
					String id = rs.getString("id");
					String sinkId = rs.getString("sink_id");
					String contMethodId = rs.getString("sink_exist_in_method_id");
					String paramId = rs.getString("param_mapping_id");
					String depMethodId = rs.getString("dependent_method_id");
					String lineNo = rs.getString("sink_line_num");
					String calleeParamId = rs.getString("processing_callee_param_id");
					String callerParamId = rs.getString("processing_caller_param_id");
	
					Sink sink = getSink(sinkId + "_" + lineNo, sinks);
					sink.setLineNo(Integer.parseInt(lineNo));
					sink.setId(sinkId + "_" + lineNo);
					sink.setContainerMethod(pbdMethod);				
					
					
					
					String sinkCompoId = sink.getId();
					if(!"-1".equals(depMethodId)){
											
						List<String> lstString = sinkDependentMethods.get(sinkCompoId);
						if(lstString==null){
							lstString = new ArrayList<String>();
							lstString.add(depMethodId+","+calleeParamId);
							sinkDependentMethods.put(sinkCompoId, lstString);
						}
						else
						{
							lstString.add(depMethodId+","+calleeParamId);
							sinkDependentMethods.put(sinkCompoId, lstString);
						}
						
						List<String> depParamList = dependentParamsGroups.get(sinkCompoId);
						if(depParamList == null){
							depParamList = new ArrayList<String>();
							depParamList.add(paramId+","+callerParamId);
						}
						else
						{
							depParamList.add(paramId+","+callerParamId);
						}
						dependentParamsGroups.put(sinkCompoId, depParamList);
					}
					else
					{
						/*if(!"-1".equals(paramId)){
							directMethodParameters.add(getMethodParameter(Long.parseLong(paramId)));
						}*/
						
						if(!"-1".equals(paramId)){
							List<PbDMethodParameter> directMethodParameters = directParamsMap.get(sinkCompoId);
							if(directMethodParameters == null)
								directMethodParameters = new ArrayList<PbDMethodParameter>();
							
							directMethodParameters.add(getMethodParameter(Long.parseLong(paramId)));
							directParamsMap.put(sinkCompoId, directMethodParameters);
						}
						
						List<String> lstString = sinkDependentMethods.get(sinkCompoId);
						if(lstString == null)
							sinkDependentMethods.put(sinkCompoId, null);
						
						List<String> directParamsList = directParamsGroups.get(sinkCompoId);
						if(directParamsList == null){
							directParamsList = new ArrayList<String>();
							directParamsList.add(paramId+","+callerParamId);
						}
						else
						{
							directParamsList.add(paramId+","+callerParamId);
						}
						directParamsGroups.put(sinkCompoId, directParamsList);
					}
				}
				
				processDirectParameters(directParamsMap, sinks);
				
				processDirectParamsGroup(directParamsGroups, pbdMethod.getParameters().size(), sinks);
				processDependentParamsGroup(dependentParamsGroups,pbdMethod.getParameters().size(), sinks);
				
				Set<Entry<String, List<String>>> entriesSet = sinkDependentMethods.entrySet();
				Iterator<Entry<String, List<String>>> entriesIter = entriesSet.iterator();
				while(entriesIter.hasNext()){
					Entry<String, List<String>> entry = entriesIter.next();
					String key = entry.getKey();
					List<String> value = entry.getValue();
					
					//If sink is not dependent on any callee, set it to null
					if(value==null)
					{
						Sink sink = getSink(key.toString(), sinks);
						sink.setSinkDependencies(null);
						continue;
					}
					
					Map<String, List<String>> methodParaAsso = processValue(value);
					Set<Entry<String, List<String>>> methodParamsSet = methodParaAsso.entrySet();
					Iterator<Entry<String,List<String>>> assocIter = methodParamsSet.iterator();
					
					List<SinkDependency> lstSinkDependency = new ArrayList<SinkDependency>();
					
					while(assocIter.hasNext()){
						Entry<String, List<String>> assocEntry = assocIter.next();
						String method = assocEntry.getKey();
						List<String> methodParameters = assocEntry.getValue();
						PbDMethod dependentMethod = getMethodInfo(Long.parseLong(method));
						List<PbDMethodParameter> listDepMethodPara = getSelectedParasOfMethod(dependentMethod, methodParameters);
						
						SinkDependency sinkDependency = new SinkDependency();
						sinkDependency.setDependentOnCallee(true); // revise flag if all dependent parameters are primitive
						sinkDependency.setPbDMethod(dependentMethod);
						sinkDependency.setParameters(listDepMethodPara);
						
						lstSinkDependency.add(sinkDependency);
					}
					
					Sink sink = getSink(key.toString(), sinks);
					sink.setSinkDependencies(lstSinkDependency);					
				}
			}
			
			 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("SQL exception while fetching sinks data");
			}
		
		}
		return sinks;
	}
	
	private void processDirectParameters(Map<String, List<PbDMethodParameter>> directParasMap, List<Sink> sinks){
		Set<Entry<String, List<PbDMethodParameter>>> entrySet = directParasMap.entrySet();
		Iterator<Entry<String, List<PbDMethodParameter>>> iter = entrySet.iterator();
		while(iter.hasNext()){
			Entry<String, List<PbDMethodParameter>> entry = iter.next();
			String key = entry.getKey();
			List<PbDMethodParameter> list = entry.getValue();
			Sink sink = getSink(key, sinks);
			sink.setDirectParameter(list);
		}
	}
	
	private void processDependentParamsGroup(Map<String, List<String>> dependentParams, int paraCount, List<Sink> sinks){
		Set<Entry<String, List<String>>> entries = dependentParams.entrySet();
		Iterator<Entry<String, List<String>>> iter = entries.iterator();
		
		//Map<Sink, Integer> mapLocalCount = new HashMap<Sink, Integer>();
		
		while(iter.hasNext()){
			Entry<String, List<String>> entry = iter.next();
			String key = entry.getKey();
			List<String> value = entry.getValue();
			int count = processParameters(key, value, paraCount);
			Sink sink = getSink(key, sinks);
			sink.setLocalLeakCount(count);
		}
	}
	private void processDirectParamsGroup(Map<String, List<String>> directParams, int paraCount, List<Sink> sinks){
		processDependentParamsGroup(directParams, paraCount, sinks);
		
	}
	
	private int processParameters(String sinkId, List<String> params, int paraCount)
	{
		Map<Long, List<Long>> mapOfParameters = new HashMap<Long, List<Long>>();
		//List<long[]> listOfLongs = new ArrayList<long[]>();
		for(int i=0;  i< params.size(); i++){
			String parameters = params.get(i);
			String[] strValues = parameters.split(",");
			Long param = Long.parseLong(strValues[1]);
			List<Long> paramList = mapOfParameters.get(param);
			if(paramList == null){
				paramList = new ArrayList<Long>();
			}
			paramList.add(Long.parseLong(strValues[0]));
			mapOfParameters.put(param, paramList);
			/*String parameters = params.get(i);
			String[] strValues = parameters.split(",");
			long[] lngValues = new long[strValues.length];
			for(int j=0; j<strValues.length; j++){
				lngValues[j] = Long.parseLong(strValues[j]);
			}
			listOfLongs.add(lngValues);*/
		}
		
		int localLeakCount = 0;
		
		if(mapOfParameters.entrySet().size() > 0){
			int count = mapOfParameters.get(mapOfParameters.entrySet().iterator().next().getKey()).size();
			boolean flag = true;
			for(int i=0; i<count; i++){
				flag = true;
				Iterator<Entry<Long, List<Long>>> iter = mapOfParameters.entrySet().iterator();
				while(iter.hasNext()){
					Entry<Long, List<Long>> entry = iter.next();
					if(i < entry.getValue().size()){
					Long lstVal = entry.getValue().get(i);
					if(lstVal != -1){
						flag = false;
					}
					}
				}
				if(flag)
					localLeakCount = localLeakCount + 1;
			}
		}
		
		return localLeakCount;
		
		
		
/*		//what if paraCount is zero. All parameters are locally generated. Handle case before calls
		int groupCount = params.size()/paraCount;
		
		System.out.println("Param size is :: " + params.size());
		System.out.println("Param count is :: " + paraCount);
		System.out.println("Group count is :: " + groupCount);
		
		//use map instead..
		
		Map<Long, List<Long>> mapOfParameters = new HashMap<Long, List<Long>>();
		
		List<Group> listOfGroups = new ArrayList<Group>();
		for(int i=0; i<params.size(); i++)
		{
			long[] vals = listOfLongs.get(i);
			if(listOfGroups.size()==0)
			{
				Group g = new Group(paraCount);
				listOfGroups.add(g);
				g.addInGroup(vals[0], vals[1]);
			}
			else
			{
				for(int j=0; j<listOfGroups.size(); j++){
					Group g = listOfGroups.get(j);
					if(g.processingCallerMappingId.length < paraCount){
						g.addInGroup(vals[0], vals[1]);
					}
				}
				Group g = findGroup(vals, listOfGroups);
				if(g == null){
					Group g1 = new Group(paraCount);
					listOfGroups.add(g1);
					g1.addInGroup(vals[0], vals[1]);
				}
				else
				{
					g.addInGroup(vals[0], vals[1]);
				}
			}
		}
		
		System.out.println("Final group count is :: " + listOfGroups.size());
		
		int counter = 0;
		
		for(int i=0; i<listOfGroups.size(); i++)
		{
			Group g = listOfGroups.get(i);
			int cnt = g.paramMappingId.length;
			for(int j=0; j<cnt; j++)
			{
				if(g.paramMappingId[j] != -1 && g.processingCallerMappingId[j] != -1){
					counter = counter + 1;
				}
			}
		}

		return counter;*/
	}
	
	private Group findGroup(long[] vals, List<Group> groups){
		for(int i=0; i<groups.size(); i++){
			Group grp = groups.get(i);
			if(/*grp.existParamMappingId(vals[0]) && */grp.existCallerMappingId(vals[1]))
				return grp;
		}
		return null;
	}
	
	private class Group
	{
		long[] paramMappingId;
		long[] processingCallerMappingId;
		int count;
		
		public Group(int size){
			paramMappingId = new long[size];
			processingCallerMappingId = new long[size];
			count=0;
		}
		
		public boolean existCallerMappingId(long id){
			for(int i=0; i<processingCallerMappingId.length; i++){
				if(id==processingCallerMappingId[i])
					return true;
			}
			return false;
		}
		
		public boolean existParamMappingId(long id){
			for(int i=0; i<paramMappingId.length; i++){
				if(id == paramMappingId.length)
					return true;
			}
			return false;
		}
		
		public void addInGroup(long val1, long val2){
			paramMappingId[count] = val1;
			processingCallerMappingId[count] = val2;
			count++;
		}
		
	}
	

	
	private Sink getSink(String sinkCompId, List<Sink> sinks){
				
		for(int i=0; i<sinks.size(); i++){
			Sink sink = sinks.get(i);
			if(sink.getId().equalsIgnoreCase(sinkCompId))
				return sink;
		}
		Sink newSink = new Sink();
		sinks.add(newSink);
		return newSink;
		
	}
	
	/**
	 * Sink may be dependent on multiple parameters of a single callee.
	 * This method handle that scenario
	 * 
	 * @param values
	 * @return
	 */
	private Map<String, List<String>> processValue(List<String> values){
		Map<String, List<String>> mapMethodParams = new HashMap<String, List<String>>();
		for(int i=0; i<values.size(); i++){
			String value = values.get(i);
			String[] methodPrams = value.split(",");
			List<String> listParams = mapMethodParams.get(methodPrams[0]);
			if(listParams == null){
				listParams = new ArrayList<String>();
				listParams.add(methodPrams[1]);
				mapMethodParams.put(methodPrams[0], listParams);
				
			}
			else
			{
				if(!listParams.contains(methodPrams[1]))
					listParams.add(methodPrams[1]);
				
				mapMethodParams.put(methodPrams[0], listParams);
			}			
		}
		return mapMethodParams;
	}
	
	/**
	 * Method checks the inherited context which is of interest to a caller
	 * @param callee
	 * @return
	 */
	public Context checkMethodInheritContext(PbDMethod callee, PbDMethod caller){
		
		List<PbDMethodParameter> callerMethodParams = null;
		List<PbDMethodParameter> calleeMethodParams = null;
		
		
		
		if (connection != null) {
			Statement stmt;
			
		List<String> callerParams = new ArrayList<String>();
		List<String> calleeParams = new ArrayList<String>();
		
		try {
			
			stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.inheritContextQuery_1 + caller.getId() + DatabaseQueries.inheritContextQuery_2 + callee.getId());
			
			List<PbDMethodParameter> paraList = new ArrayList<PbDMethodParameter>();
			
			while(rs.next()){
				
				String callerMethodId = rs.getString("method_id");
				
				String calleeMethodId = rs.getString("callee_id");
				
				String callSiteNo = rs.getString("callsite_line_num");
				
				String callerParameterId = rs.getString("parameter_id");
				
				boolean changedValue = rs.getBoolean("changed_value");
				
				int calleeIndex = rs.getInt("callee_index");
				
				String callerParameterIndex = rs.getString("caller_index");//t2.caller_index
				
				String valueChangeLineNo = rs.getString("change_value_line_num");
				
				String calleeParameterId = rs.getString("callee_parameter_id");
				
				// This block takes care of whether parameter is getting inherited or not
				// Second level of check ensure parameter value is changing or not
				// Third level of check ensure parameter is changing before or after callsite
				if(calleeIndex != -1){
					if(!changedValue){
						callerParams.add(callerParameterId);
						calleeParams.add(calleeParameterId);
					}
					else
					{
						if(Long.parseLong(callSiteNo) < Long.parseLong(valueChangeLineNo)){
							callerParams.add(callerParameterId);
							calleeParams.add(calleeParameterId);
						}
					}
				}
				
			}
			
		
			
			if(callerParams.size() != 0){
								
				callerMethodParams = getSelectedParasOfMethod(caller, callerParams);
				calleeMethodParams = getSelectedParasOfMethod(callee, calleeParams);
				
				//residualCntx = getResidualContext(callerMethodParams, calleeMethodParams);
				
			}
			
			
			//context which is not getting killed
			
			//getResidualContext(recCntx, lstKillSet);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		Context inhCntx = new Context();
		inhCntx.setLineNo(-1);
		inhCntx.setContextType(ContextType.inherited);
		inhCntx.setOriginalPbDParameters(callerMethodParams);
		inhCntx.setNewPbDParameters(calleeMethodParams);
		return inhCntx;		
	}
	
	/**
	 * Method checks the inherited context which is of interest to a caller
	 * @param callee
	 * @return
	 */
	public Context getKilledContext(PbDMethod callee, PbDMethod caller){
		
		List<PbDMethodParameter> killedParams = null;
		
		if (connection != null) {
			Statement stmt;
			
		List<String> callerParams = new ArrayList<String>();
		List<String> calleeParams = new ArrayList<String>();
		
		try {
			
			stmt = connection.createStatement();
			
			ResultSet rs = stmt.executeQuery(DatabaseQueries.killContextQuery_1 + caller.getId() + DatabaseQueries.killContextQuery_2 + callee.getId());
			
			List<PbDMethodParameter> paraList = new ArrayList<PbDMethodParameter>();
			
			while(rs.next()){
				
				String callerMethodId = rs.getString("method_id");
				
				String calleeMethodId = rs.getString("callee_id");
				
				String callSiteNo = rs.getString("callsite_line_num");
				
				String callerParameterId = rs.getString("parameter_id");
				
				boolean changedValue = rs.getBoolean("changed_value");
				
				String calleeParameterIndex = rs.getString("callee_index");
				
				String callerParameterIndex = rs.getString("caller_index");//t2.caller_index
				
				String valueChangeLineNo = rs.getString("change_value_line_num");
				
				String calleeParameterId = rs.getString("callee_parameter_id");
				

				if(changedValue){
					if(Long.parseLong(callSiteNo) > Long.parseLong(valueChangeLineNo)){
						callerParams.add(callerParameterId);
						//calleeParams.add(calleeParameterId);
					}
				}
				
			}
			
			//List<PbDMethodParameter> callerMethodParams = null;
			//List<PbDMethodParameter> calleeMethodParams = null;
			
			
			
			if(callerParams.size() != 0){
								
				killedParams = getSelectedParasOfMethod(caller, callerParams);
				//calleeMethodParams = getSelectedParasOfMethod(callee, calleeParams);
				
				//killedParams = getResidualContext(callerMethodParams, calleeMethodParams);
				
			}
			
			
			//context which is not getting killed
			
			//getResidualContext(recCntx, lstKillSet);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		Context killCntx = new Context();
		killCntx.setLineNo(-1);
		killCntx.setContextType(ContextType.killed);
		killCntx.setOriginalPbDParameters(killedParams);
		killCntx.setNewPbDParameters(null);
		return killCntx;		
	}
	
	/**
	 * Method checks the inherited context which is of interest to a caller
	 * @param callee
	 * @return
	 */
	public Context getKilledSingleMethod(PbDMethod pbdMethod){
		
		List<PbDMethodParameter> killedParams = null;
		
		if (connection != null) {
			Statement stmt;
			
		List<String> callerParams = new ArrayList<String>();
		List<String> calleeParams = new ArrayList<String>();
		
		try {
			
			stmt = connection.createStatement();
						
			ResultSet rs = stmt.executeQuery(DatabaseQueries.killSingleMethodQuery_1 + pbdMethod.getId() + DatabaseQueries.killSingleMethodQuery_2 + 0);
			
			List<PbDMethodParameter> paraList = new ArrayList<PbDMethodParameter>();
			
			while(rs.next()){
				
				String callerMethodId = rs.getString("method_id");
				
				String calleeMethodId = rs.getString("callee_id");
				
				String callSiteNo = rs.getString("callsite_line_num");
				
				String callerParameterId = rs.getString("parameter_id");
				
				boolean changedValue = rs.getBoolean("changed_value");
				
				String calleeParameterIndex = rs.getString("callee_index");
				
				String callerParameterIndex = rs.getString("caller_index");//t2.caller_index
				
				String valueChangeLineNo = rs.getString("change_value_line_num");
				
				String calleeParameterId = rs.getString("callee_parameter_id");
				

				if(changedValue){
					//if(Long.parseLong(callSiteNo) > Long.parseLong(valueChangeLineNo)){
						callerParams.add(callerParameterId);
						//calleeParams.add(calleeParameterId);
					//}
				}
				
			}
			
			//List<PbDMethodParameter> callerMethodParams = null;
			//List<PbDMethodParameter> calleeMethodParams = null;
			
			
			
			if(callerParams.size() != 0){
								
				killedParams = getSelectedParasOfMethod(pbdMethod, callerParams);
				//calleeMethodParams = getSelectedParasOfMethod(callee, calleeParams);
				
				//killedParams = getResidualContext(callerMethodParams, calleeMethodParams);
				
			}
			
			
			//context which is not getting killed
			
			//getResidualContext(recCntx, lstKillSet);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		Context killCntx = new Context();
		killCntx.setLineNo(-1);
		killCntx.setContextType(ContextType.killed);
		killCntx.setOriginalPbDParameters(killedParams);
		killCntx.setNewPbDParameters(null);
		return killCntx;		
	}
	
	/**
	 * residual context is obtained by taking set difference between parameters of context and killset
	 * 
	 * @param recentCntx
	 * @param lstKillSet
	 */
/*	private void getResidualContext(Context recentCntx, List<KillSet> lstKillSet){
		
		List<PbDMethodParameter> pbdMethodParams = recentCntx.getParameters();
			
		for(int i=0; i<pbdMethodParams.size(); i++){
			
			PbDMethodParameter pbdMethodpara = pbdMethodParams.get(i);
			
			for(int j=0; j<lstKillSet.size(); j++){	
				
			KillSet killedPara = lstKillSet.get(j);
			
				if(pbdMethodpara.getName().equalsIgnoreCase(killedPara.getParameter().getName())){
					if(killedPara.getLineNo() < recentCntx.getLineNo()){
						pbdMethodParams.remove(i);
					}
				}
			}
		}
		
	}*/
	
	/**
	 * residual context is obtained by taking set difference between parameters of context and killset
	 * 
	 * @param recentCntx
	 * @param lstKillSet
	 */
/*	private List<PbDMethodParameter> getResidualContext(List<PbDMethodParameter> callerList, List<PbDMethodParameter> calleeList){
		
		List<PbDMethodParameter> pbdMethodParams = callerList;
		
		List<PbDMethodParameter> residualCntx = new ArrayList<PbDMethodParameter>();
			
		for(int i=0; i<pbdMethodParams.size(); i++){
			
			PbDMethodParameter pbdMethodpara = pbdMethodParams.get(i);
			
			for(int j=0; j<calleeList.size(); j++){	
			
				if(pbdMethodpara.getName().equalsIgnoreCase(calleeList.get(j).getName())){
					if(!pbdMethodpara.isPrimitive()){
						residualCntx.add(pbdMethodpara);
					}
				}
			}
		}
		
		return residualCntx;
	}*/
	
	private ParameterType determineType(String type){
		if(type.contains("class"))
			return ParameterType.REFERENCE;
		else
			return ParameterType.PRIMITIVE;
	}
}

package com.tcs.pbd.database;

public class DatabaseQueries {

	public static String schema = "roller_master";
	
	public static String methodInfoById = "select * from " + schema +".method_info where id=";
	public static String methodCalleesById = "select * from " + schema +".method_callee where method_id=";
	
	public static String methodParametersById = "select * from " + schema + ".method_parameters where method_id=";
	public static String paramById = "select * from " + schema + ".method_parameters where id =";
	
	public static String methodParametersByIdAndParameterList_1 = "select * from " + schema + ".method_parameters where method_id=";
	public static String methodParametersByIdAndParameterList_2 = " and id in ("; 
	public static String methodParametersByIdAndParameterList_3 = ")";
	
	public static String methodSinksBySinkMethodId = "select * from " + schema + ".method_leak where sink_exist_in_method_id =";
	
	public static String inheritContextQuery_1 = "select t1.method_id, t1.callee_id, t1.callsite_line_num, t2.parameter_id, t2.changed_value, t2.callee_index, t2.caller_index, t2.change_value_line_num, t2.callee_parameter_id from " + schema + ".method_callee t1, " + schema + ".method_parameter_mapping t2 where t1.id = t2.method_callee_id and t1.method_id = ";
	public static String inheritContextQuery_2 = " and t1.callee_id = ";
	
	public static String killContextQuery_1 = "select t1.method_id, t1.callee_id, t1.callsite_line_num, t2.parameter_id, t2.changed_value, t2.callee_index, t2.caller_index, t2.change_value_line_num, t2.callee_parameter_id from " + schema + ".method_callee t1, " + schema + ".method_parameter_mapping t2 where t1.id = t2.method_callee_id and t1.method_id = ";
	public static String killContextQuery_2 = " and t1.callee_id = ";
	
	public static String killSingleMethodQuery_1 = "select t1.method_id, t1.callee_id, t1.callsite_line_num, t2.parameter_id, t2.changed_value, t2.callee_index, t2.caller_index, t2.change_value_line_num, t2.callee_parameter_id from " + schema + ".method_callee t1, " + schema + ".method_parameter_mapping t2 where t1.id = t2.method_callee_id and t1.method_id = ";
	public static String killSingleMethodQuery_2 = " and t1.callee_id = ";
	
	public static String paramSensitivityChange_1 = "select t1.method_id, t1.callee_id, t2.callee_parameter_id, t2.is_param_sensitive from webgoat.method_callee t1, webgoat.method_parameter_mapping t2 where t1.method_id = ";
	public static String paramSensitivityChange_2 = " and t1.callee_id = ";
	public static String paramSensitivityChange_3 = " and t1.id = t2.method_callee_id";
	
	
}

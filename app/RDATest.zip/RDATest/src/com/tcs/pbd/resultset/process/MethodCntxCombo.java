package com.tcs.pbd.resultset.process;

import com.tcs.pbd.context.Context;

public class MethodCntxCombo {

	private PbDMethod pbdMethod;
	private Context cntx;
	private ParameterNode paramNode;
	
	public PbDMethod getPbDMethod() { return pbdMethod; }
	
	public Context getContext() { return cntx; }
	
	public void setPbDMethod(PbDMethod pbdMethod) { this.pbdMethod = pbdMethod; }
	
	public void setContext(Context newCntx) { this.cntx = newCntx; }
	
	public ParameterNode getParamNode() { return paramNode; }
	
	public void setParameterNode(ParameterNode newNode){
		this.paramNode = newNode;
	}
	
}

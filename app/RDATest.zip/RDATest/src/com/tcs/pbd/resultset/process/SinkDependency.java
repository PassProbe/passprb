package com.tcs.pbd.resultset.process;

import java.util.List;

public class SinkDependency {
	
	private boolean dependentOnCallee;
	private PbDMethod pbdMethod;
	private List<PbDMethodParameter> parameters;
	
	public PbDMethod getPbDMethod(){
		return pbdMethod;
	}
	public boolean isDependentOnCallee(){		
		return dependentOnCallee;
	}
	public List<PbDMethodParameter> getDependentMethodParameters(){
		return parameters;
	}

	public void setDependentOnCallee(boolean flag){
		this.dependentOnCallee = flag;
	}
	
	public void setPbDMethod(PbDMethod pbdMethod){
		this.pbdMethod = pbdMethod;
	}
	
	public void setParameters(List<PbDMethodParameter> parameters){
		this.parameters = parameters;
	}
}

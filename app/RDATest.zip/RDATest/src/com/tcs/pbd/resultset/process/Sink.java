package com.tcs.pbd.resultset.process;

import java.util.List;

public class Sink {

	private String id;
	private String name;	
	private int lineNo;
	private List<SinkDependency> sinkDependencies;
	private PbDMethod containerMethod;
	private List<PbDMethodParameter> directParameters;
	private int localLeakCnt; // total number of locally generated units
	
	public int getLocalLeaks() { return localLeakCnt; }
	
	public void setLocalLeakCount(int count) { this.localLeakCnt = count; }
	
	public void setDirectParameter(List<PbDMethodParameter> directParas) { directParameters = directParas;}
	
	public List<PbDMethodParameter> getDirectParameters() { return directParameters; }
	
	public List<SinkDependency> getSinkDependencies(){		
		return sinkDependencies;
	}
	
	public String getName(){
		return name;
	}
	
	public String getId() {
		return id;
	}
	
	public int getLineNo() { return lineNo; }
	
	public PbDMethod getContainerMethod() { return containerMethod; }
	
		
	public void setLineNo(int lineNo){
		this.lineNo = lineNo;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setId(String id){
		this.id = id;
	}
	
	public void setSinkDependencies(List<SinkDependency> dependencies){
		this.sinkDependencies = dependencies;
	}
	
	public void setContainerMethod(PbDMethod containerMethod){
		this.containerMethod = containerMethod;
	}
}

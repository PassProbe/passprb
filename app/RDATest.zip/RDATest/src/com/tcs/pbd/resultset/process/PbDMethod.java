package com.tcs.pbd.resultset.process;

import java.sql.ResultSet;
import java.util.List;

public class PbDMethod {
	
	private String name;
	
	private long id;
	
	private int depth;
	
	private boolean boundaryMethod;
	
	private List<Callee> callees;
	
	private List<Sink> sinks;
	
	private List<PbDMethodParameter> parameters;
	
	private boolean isEvaluated;
	
	private PbDMethod currentCaller;
	
	public PbDMethod(){
		
	}
	
	public List<Callee> getCallees(){
		
		return callees;
	}
	
	public List<Sink> getSinks(){		
		return sinks;
	}
	
	public List<PbDMethodParameter> getParameters(){		
		return parameters;
	}
	
	public boolean isBoundaryMethod(){		
		return boundaryMethod;
	}
	
	public String getName(){		
		return name;
	}
	
	public boolean IsEvaluated(){		
		return isEvaluated;
	}
	
	public int getDepth(){
		return depth;
	}
	
	public long getId(){
		return id;
	}
	
	public PbDMethod getCurrentCaller(){
		return currentCaller;
	}
	
	public void setEvaluated(boolean flag){
		this.isEvaluated = flag;
	}
	
	public void setCurrentCaller(PbDMethod currentCaller){
		this.currentCaller = currentCaller;
	}
	
	public void setDepth(int depth){
		this.depth = depth;
	}
	
	public void setIsBoundaryMethod(boolean flag){
		this.boundaryMethod = flag;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setCallees(List<Callee> callees){
		this.callees = callees;
	}
	
	public void setSinks(List<Sink> sinks){
		this.sinks = sinks;
	}
	
	public void setId(long id){
		this.id = id;
	}
	
	public void setParameters(List<PbDMethodParameter> parameters){
		this.parameters = parameters;
	}
	
	public boolean equals(Object p){
		
		if(p==null)
			return false;
		
		if(!(p instanceof PbDMethod))
			return false;
		
		PbDMethod temp = (PbDMethod)p;
		
		if(temp.getId()==this.getId())
			return true;
		
		return false;
	}
	
	public int hashCode(){
		
		int result = 17;
		
		result = 31 * result + (int)(id ^ (id >>> 32));
		
		return result;
	}

}

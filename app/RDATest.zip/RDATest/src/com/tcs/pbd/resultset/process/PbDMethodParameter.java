package com.tcs.pbd.resultset.process;

public class PbDMethodParameter {

	private long id;
	private boolean isPrimitive;
	private Object refType;
	private int index;
	private boolean sensitivity;
	private String name;
	private boolean killed;
	private boolean inUse;
	private boolean inherit;
	
	public boolean isKilled() { return killed; }
	
	public boolean inUse() { return inUse; }
	
	public boolean inHerit() { return inherit; }
	
	public void setKilled(boolean flag) { this.killed=flag;}
	
	public void setInUse(boolean flag) {this.inUse = flag;}
	
	public void setInherit(boolean flag) {this.inherit = flag;}
	
	public boolean isPrimitive() { return isPrimitive;	}
	
	public String getName() { return name; }
	
	public int getIndex() { return index; }
	
	public boolean isSensitive(){ return sensitivity; }
	
	public long getId () { return id; }
	
	public void setIsPrimitive(boolean flag){
		this.isPrimitive = flag;
	}
	
	public void setId(long id){
		this.id = id;
	}
	
	public void setSensitivity(boolean flag){
		this.sensitivity = flag;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setIndex(int index){
		this.index = index;
	}
}

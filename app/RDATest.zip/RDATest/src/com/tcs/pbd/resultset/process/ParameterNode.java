package com.tcs.pbd.resultset.process;

import java.util.HashMap;
import java.util.Map;



public class ParameterNode {

	private long values[];
	private ParameterNode children[];
	
	public long[] getValue() { return values; }
		
	public ParameterNode(long[] parameterValues){
		values = new long[parameterValues.length];
		for(int i=0; i<parameterValues.length; i++){			
			this.values[i] = parameterValues[i];
		}		
	}
	
	public void createChildren(int childCnt, long[][] values){
		children = new ParameterNode[childCnt];
		for(int i=0; i<childCnt; i++){
			long[] paramValues = values[i];
			children[i] = new ParameterNode(paramValues);
		}
	}
	
	public void setChildren(ParameterNode children[]){
		this.children = children;
	}
	
	public ParameterNode createChild(long[] paramVals){
		ParameterNode paramNode = new ParameterNode(paramVals);
		return paramNode;
	}
	
	public void setChild(int index, ParameterNode child){
		this.children[index] = child;
	}
	
	public ParameterNode getChild(int index){
		return children[index];
	}
	
	public int getChildrenCount() { if(children == null) return 0; else return children.length; }
	
	public int getIndex(long parameterId){
		
		for(int i=0; i<values.length; i++){
			if(values[i] == parameterId)
				return i;
		}
		return -1;		
	}
	
	public String toString(){
		
		if(this == null)
			return "null";
		
		StringBuilder nodeStr = new StringBuilder();
		
		nodeStr.append("{");
		for(int i=0; i<values.length; i++){
			nodeStr.append(values[i] + ",");
		}
		nodeStr.append("} : count -> ");
		nodeStr.append(getChildrenCount());
		
		return nodeStr.toString();
	}
	
}

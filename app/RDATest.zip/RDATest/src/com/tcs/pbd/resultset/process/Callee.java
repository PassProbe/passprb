package com.tcs.pbd.resultset.process;

public class Callee {

	private long calleeId;
	private String callSite;
	private int lineNo;
	private PbDMethod pbdMethod;
	
	public long getCalleeId() { return calleeId; }
	
	public String getCallSite() { return callSite; }
	
	public int getLineNo() { return lineNo; }
	
	public PbDMethod getPbDMethod() { return pbdMethod; }
	
	public void setCalleeId(long calleeId) { this.calleeId = calleeId; }
	
	public void setCallSite(String callSite) { this.callSite = callSite; }
	
	public void setLineNo(int lineNo) { this.lineNo = lineNo; }
	
	public void setPbDMethod(PbDMethod method) { this.pbdMethod = method; }
}

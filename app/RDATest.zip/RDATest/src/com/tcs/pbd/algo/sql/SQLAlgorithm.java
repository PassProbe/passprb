package com.tcs.pbd.algo.sql;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;

import javax.swing.plaf.synth.SynthSeparatorUI;

import com.tcs.pbd.context.Context;
import com.tcs.pbd.context.ContextType;
import com.tcs.pbd.context.VariableState;
import com.tcs.pbd.database.DatabaseUtils;
import com.tcs.pbd.resultset.process.Callee;
import com.tcs.pbd.resultset.process.MethodCntxCombo;
import com.tcs.pbd.resultset.process.ParameterNode;
import com.tcs.pbd.resultset.process.PbDMethod;
import com.tcs.pbd.resultset.process.PbDMethodParameter;
import com.tcs.pbd.resultset.process.Sink;
import com.tcs.pbd.resultset.process.SinkDependency;


public class SQLAlgorithm {
	
	Map<String, List<Sink>> methodToSinks = new HashMap<String, List<Sink>>();
	
	Map<String, Queue<PbDMethod>> methodToCallee = new HashMap<String, Queue<PbDMethod>>();
	
	Queue<MethodCntxCombo> sinkDepQueue = new LinkedList<MethodCntxCombo>();

	static DatabaseUtils dbUtils = new DatabaseUtils();
	
	Queue<PbDMethod> methodQueue = new LinkedList<PbDMethod>();
	
	Map<Integer, Set<Long>> mapIndexChanges = new HashMap<Integer, Set<Long>>();
	
	Queue<ParameterNode> paramQueue = new LinkedList<ParameterNode>();
	
	public void startAlgorithm() throws FileNotFoundException{
				
		FileOutputStream fileOS = new FileOutputStream(new File("C:\\SafeMask Data\\Research\\Euro_S&P_2018\\Experiments\\rollermaster.txt"), true);
		PrintStream ps = new PrintStream(fileOS);
		System.setOut(ps);
		dbUtils.getConnection();
		PbDMethod pbdMethod = dbUtils.getMethodInfo(2); //47, 48 of altoroj remaining. 10 of javalibrary (ask monica). 127, 149 of jspwiki
		pbdMethod.setCurrentCaller(null);
		methodQueue.add(pbdMethod);
		
		int totalLeakCount = 0;
		int totalSenLeakCount = 0;
		int totalDepLeakCount = 0;
		int totalDirLeakCount = 0;
		int localLeakCount =0;
		int killedCount = 0;
		int inUseCount = 0;
		int inheritCount = 0;
		
		pbdMethod = methodQueue.poll();
		
		while(pbdMethod != null){
					
			List<Callee> callees = dbUtils.getMethodCallees(pbdMethod);
			pbdMethod.setCallees(callees);
			
			for(int i=0; i<callees.size(); i++){
				
				PbDMethod newMethod = callees.get(i).getPbDMethod();
				newMethod.setCurrentCaller(pbdMethod);
				//if(!methodQueue.contains(newMethod))
					methodQueue.add(newMethod);
			}
						
			List<PbDMethodParameter> methodParameters = dbUtils.getMethodParameters(pbdMethod);
						
			List<Sink> sinks = dbUtils.getMethodSinks(pbdMethod);
			

			
			for(int i=0; i<sinks.size(); i++){
				
				Sink sink = sinks.get(i);
		
				List<PbDMethodParameter> killedSensParams = new ArrayList<PbDMethodParameter>();
				
				localLeakCount = localLeakCount + sink.getLocalLeaks();
				
				if(sink.getSinkDependencies()==null || sink.getSinkDependencies().size()==0){
					
					if(sink.getDirectParameters() != null && sink.getDirectParameters().size()>0){
						if(pbdMethod.getCurrentCaller() != null){
							refineParameterSensitivity(sink.getDirectParameters(), pbdMethod.getCurrentCaller(), pbdMethod);
						}
						for(int j=0; j<sink.getDirectParameters().size(); j++){
							
							PbDMethodParameter param = sink.getDirectParameters().get(j);
							
							if(param.isSensitive())
								totalSenLeakCount= totalSenLeakCount+1;
							else
								totalDirLeakCount = totalDirLeakCount + 1;
						}
					}
					
					
					//query application summary if sensitivities of parameters are not known for chosen method
					
				}
				else
				{					
					List<SinkDependency> sinkDeps = sink.getSinkDependencies();
										
					for(int j=0;j<sinkDeps.size();j++){
												
						SinkDependency sinkDep = sinkDeps.get(j);
						
						//Order of sink dependency is important and the parameters (context) on which it is
						//dependent
						
						List<PbDMethodParameter> contxParams = sinkDep.getDependentMethodParameters();
						
						ParameterNode rootNode = createRootParameterNode(contxParams);
						ParameterNode copyRootNode = rootNode;
												
						/**
						 * Check whether any parameter between sink and dependent method is getting killed or not
						 * 
						 */
						
						//create initial context and passed it to method
						Context cntx = new Context();
						cntx.setOriginalPbDParameters(contxParams);
						cntx.setNewPbDParameters(null);
						cntx.setContextType(ContextType.inherited);
						cntx.setLineNo(-1);
						
						evaluateSinkDependency2(sinkDep.getPbDMethod(), cntx, rootNode);
						
						evaluateRootNode(copyRootNode);
						processStateMapping(mapIndexChanges, contxParams);
						
						for(int p=0; p<contxParams.size(); p++){
							if(!contxParams.get(p).isKilled()){
								if(contxParams.get(p).isSensitive())
									totalSenLeakCount = totalSenLeakCount + 1;
								else
									totalDepLeakCount = totalDepLeakCount + 1;
							}
							else
							{
								killedCount = killedCount + 1;
							}
							if(contxParams.get(p).inUse())
							{
								inUseCount = inUseCount + 1;
							}
							if(contxParams.get(p).inHerit()){
								
								inheritCount = inheritCount + 1;
							}
								
						}
						
						if(sink.getDirectParameters() != null && sink.getDirectParameters().size()>0){
							if(pbdMethod.getCurrentCaller() != null){
								refineParameterSensitivity(sink.getDirectParameters(), pbdMethod.getCurrentCaller(), pbdMethod);
							}
						
							for(int t=0; t<sink.getDirectParameters().size(); t++){
							
							PbDMethodParameter param = sink.getDirectParameters().get(t);
							
							if(param.isSensitive())
								totalSenLeakCount= totalSenLeakCount+1;
							else
								totalDirLeakCount = totalDirLeakCount + 1;
							}
						}
						
						mapIndexChanges.clear();
						paramQueue.clear();
						
					}
					
					/*for(int j=0; j<sinkDeps.size(); j++){
						if(sinkDeps.get(j).isDependentOnCallee()){
							//System.out.println("Sink : " + sink.getName() + " is dependent on " + sinkDeps.get(j).getPbDMethod().getName());
						}
					}*/
				}
			}
			
			pbdMethod = methodQueue.poll();
		}
		
		totalLeakCount = totalLeakCount + (totalDirLeakCount + totalDepLeakCount + localLeakCount + totalSenLeakCount);
		
		System.out.println("Direct total leak count :: " + (totalDirLeakCount));
		
		System.out.println("Dependent total leak count :: " + (totalDepLeakCount));
		
		System.out.println("Local leak count :: " + localLeakCount);
		
		System.out.println("Total sensitive leak count :: " + totalSenLeakCount);
		
		System.out.println("Total leak count :: " + (totalLeakCount));
		
		System.out.println("Total killed count is :: " +  killedCount);
		
		System.out.println("Total in Use count is :: " +  inUseCount);
		
		System.out.println("Total inherit count is :: " +  inheritCount);
		
		System.out.println("");

	}
	
	private void refineParameterSensitivity(List<PbDMethodParameter> pbdMethodParameters, PbDMethod caller, PbDMethod callee){
		List<PbDMethodParameter> chgSensPbdMethodParas = dbUtils.getLastMappingCallerCalleeParameters(caller, callee);
		for(int i=0; i<pbdMethodParameters.size(); i++){
			for(int j=0; j<chgSensPbdMethodParas.size(); j++){
				PbDMethodParameter para1 = pbdMethodParameters.get(i);
				PbDMethodParameter para2 = chgSensPbdMethodParas.get(j);
				if(!para1.isSensitive() && para1.getId()==para2.getId()){
					para1.setSensitivity(para2.isSensitive());
				}
			}
		}
	}
	
	private void processStateMapping(Map<Integer, Set<Long>> mappings, List<PbDMethodParameter> cntxParams){
		Set<Entry<Integer, Set<Long>>> entries = mappings.entrySet();
		Iterator<Entry<Integer, Set<Long>>> iter = entries.iterator();
		//Map<Integer>
		
		while(iter.hasNext()){
			Entry<Integer, Set<Long>> entry = iter.next();
			
			Set<Long> valueSet = entry.getValue();
			Iterator<Long> values = valueSet.iterator();
			boolean killed = true;
			boolean inUse = false;
			boolean inherit = true;
			while(values.hasNext()){
				Long element = values.next();
				if(element != -1000){
					killed = false;
				}
				if(element == -2000){
					inUse = true;
				}
			}
			if(killed==false && inUse==false){
				inherit = true;
			}
			cntxParams.get(entry.getKey()).setKilled(killed);
			cntxParams.get(entry.getKey()).setInherit(inherit);
			cntxParams.get(entry.getKey()).setInUse(inUse);
		}
	}
	
	private void evaluateRootNode(ParameterNode node){

		for(int i=0; i<node.getChildrenCount(); i++){
			
			ParameterNode child = node.getChild(i);
			long[] values = child.getValue();
			for(int j=0; j<values.length; j++){
				Set<Long> valueSet = mapIndexChanges.get(new Integer(j));
				if(valueSet == null){
					valueSet = new HashSet<Long>();
					valueSet.add(new Long(values[j]));
				}
				else
				{
					valueSet.add(new Long(values[j]));
				}
				mapIndexChanges.put(new Integer(j), valueSet);
			}
			paramQueue.add(child);
		}
		ParameterNode enqNode = paramQueue.poll();
		if(enqNode == null)
			return;
		else
			evaluateRootNode(enqNode);
	}
	
	private ParameterNode createRootParameterNode(List<PbDMethodParameter> contxParams) {
		long[] paramValues = new long[contxParams.size()];
		for(int i=0; i<contxParams.size(); i++)
		{
			paramValues[i] = contxParams.get(i).getId();
		}
		ParameterNode paraNode = new ParameterNode(paramValues);
		return paraNode;
	}
	
	private void populateMappingCntx(Map<Long, Long> mpCntx, Context cntx){
		for(int i=0; i<cntx.getOriginalParameters().size(); i++){
			mpCntx.put(new Long(cntx.getOriginalParameters().get(i).getId()), new Long(0));
		}
		
	}
	
	private void processInheritedContext(Map<Long, Long> mapping, Context inhCntx){
		for(int i=0; i<inhCntx.getOriginalParameters().size();i++){
			mapping.put(inhCntx.getOriginalParameters().get(i).getId(), inhCntx.getNewParameters().get(i).getId());
		}
	}
	
	private void processKillContext(Map<Long, Long> mapping, Context killCntx){
		for(int i=0; i<killCntx.getOriginalParameters().size();i++){		
			mapping.put(killCntx.getOriginalParameters().get(i).getId(), new Long(-1000));
		}
	}
	
	private void processUseContext(Map<Long, Long> mapping, Context useCntx){
		for(int i=0; i<useCntx.getOriginalParameters().size();i++){
			mapping.put(useCntx.getOriginalParameters().get(i).getId(), new Long(-2000));
		}
	}
	
	private ParameterNode generateParameterNodeFromMappingCntxt(Map<Long, Long> mappingCntx, ParameterNode node){
		
		Set<Entry<Long, Long>> entries =  mappingCntx.entrySet();
		Iterator<Entry<Long, Long>> iter = entries.iterator();
		
		ParameterNode newNode = null;
		long[] newValues = new long[node.getValue().length];
		
		while(iter.hasNext()){
			
			Entry<Long, Long> keyValue = iter.next();
			Long key = keyValue.getKey();
			Long value = keyValue.getValue();
			
			int index = node.getIndex(key.longValue());
			if(index != -1)
			newValues[index] = value;
			
		}
		
		newNode = new ParameterNode(newValues);
		
		return newNode;
		
	}
	
	/**
	 * Before calling this method make sure that the context being passed
	 * to pbdMethod which is passed as parameter here is not getting killed
	 * in a caller
	 * 
	 * @param pbdMethod
	 */
	public void evaluateSinkDependency2(PbDMethod pbdMethod, Context initialContext, ParameterNode node){
		
		//get initial context on which sink is dependent
		//sink use				
		List<Callee> callees =  pbdMethod.getCallees();
		
		
		
		//a boundary method
		if(callees == null || callees.size()==0){
			
			//get callees and set it for a current method
			callees = dbUtils.getMethodCallees(pbdMethod);
			
			if(callees == null || callees.size()==0 || (callees.size() == 1 && callees.get(0).getPbDMethod().getId()==0))
			{				
				//check for killed context within a method
				//what if there is no inherited context and it is not getting killed too..
				Context killContxt = dbUtils.getKilledSingleMethod(pbdMethod);
				
				Map<Long, Long> mappingCntx = new HashMap<Long, Long>();
				
				populateMappingCntx(mappingCntx, initialContext);
				
				//no need to process inherited context for boundary method
				//processInheritedContext(mappingCntx, initialContext);
				
				if(killContxt == null || killContxt.getOriginalParameters()==null){
					//process initial context
					//initialContext. Entire initial context is in use
					
					//System.out.println("Number of parameters alive are : " + initialContext);
					
				}
				else{
					//take diff between initial context and kill context
					//initialContext - killContxt. This will be in use
					
					processKillContext(mappingCntx, killContxt);
					
					Context useContext = getSetDiffCntx(initialContext, killContxt);
					
					if(useContext != null && useContext.getOriginalParameters()!=null)
						processUseContext(mappingCntx, useContext);
					
					//System.out.println("Context in use : " + useContext);
				}
			}
			
			pbdMethod.setCallees(callees);
		}
		
		for(int i=0; i<callees.size(); i++){

			PbDMethod callee = callees.get(i).getPbDMethod();
			
			Map<Long, Long> mappingCntx = new HashMap<Long, Long>();
			populateMappingCntx(mappingCntx, initialContext);
			
			int count = node.getChildrenCount();
			
			if(count == 0){
				ParameterNode[] children = new ParameterNode[callees.size()];
				node.setChildren(children);
			}
								
			Context inhContxt = dbUtils.checkMethodInheritContext(callee, pbdMethod);
			
			if(inhContxt == null || inhContxt.getNewParameters()==null){
								
				Context killContxt = dbUtils.getKilledSingleMethod(pbdMethod);
				
				Context useContext = null;
				
				if(killContxt == null || killContxt.getOriginalParameters()==null)
					useContext = initialContext;
				else{
					useContext = getSetDiffCntx(initialContext, killContxt);
					processKillContext(mappingCntx, killContxt);
				}
				
				processUseContext(mappingCntx, useContext);
				
				//System.out.println("Context is in use :: " + useContext);
				
				//create parameter node and set it as child
				ParameterNode nNode = generateParameterNodeFromMappingCntxt(mappingCntx, node);
				node.setChild(i, nNode);
			}
			else
			{
				//get kill context
				Context killContxt = dbUtils.getKilledContext(callee, pbdMethod);
				
				//System.out.println("Context which is getting killed :: " + killContxt);
				
				//subtract inherited and and killed from initial context to determine use
				//initialContext - {inhContxt U killContx}. This can be linked back to original parameter
				
				//System.out.println("During evaluation, initial context is :: " + initialContext);
				
				//System.out.println("During evaluation, inherited context is :: " + inhContxt);
				
				processInheritedContext(mappingCntx, inhContxt);
				
				Context temp = getSetDiffCntx(initialContext, inhContxt);
				
				Context useContext = null;
				
				if(killContxt == null || killContxt.getOriginalParameters()==null)
					useContext = temp;
				else{
					useContext = getSetDiffCntx(temp, killContxt);
					processKillContext(mappingCntx, killContxt);
				}
				
				if(useContext != null && useContext.getOriginalParameters()!=null)
					processUseContext(mappingCntx, useContext);
				
				ParameterNode nNode = generateParameterNodeFromMappingCntxt(mappingCntx, node);
				node.setChild(i, nNode);
				
				//System.out.println(node);
				
				//create parameter node and set it as child
				
				//System.out.println("Context in use :: " + useContext);
				
				MethodCntxCombo mCnt = new MethodCntxCombo();
				
				List<PbDMethodParameter> tempParams = inhContxt.getNewParameters();
				inhContxt.setOriginalPbDParameters(tempParams);
				inhContxt.setNewPbDParameters(null);
				
				mCnt.setContext(inhContxt);
				mCnt.setPbDMethod(callee);
				mCnt.setParameterNode(nNode);
				sinkDepQueue.add(mCnt);
			}
		}

		MethodCntxCombo child = sinkDepQueue.poll();
		if(child == null)
			return;
		else
		{
			
			evaluateSinkDependency2(child.getPbDMethod(), child.getContext(), child.getParamNode());
		}
	}
	
/*	private Context getInitialContext(List<PbDMethodParameter> depMethodParams, List<PbDMethodParameter> sinkParams){
		boolean primitiveContext = true;
		Context initalContext = new Context();
		initalContext.setLineNo(-1);
		List<PbDMethodParameter> pbdMethodParameter = new ArrayList<PbDMethodParameter>();
		for(int i=0; i<depMethodParams.size(); i++){
			for(int j=0; j<sinkParams.size(); i++){
				
				if(depMethodParams.get(i).getName().equals(sinkParams.get(j).getName())){
					pbdMethodParameter.add(depMethodParams.get(i));
				}
				
				if(!sinkParams.get(j).isPrimitive()){
					primitiveContext = false;
				}
			}
		}
		
		if(primitiveContext)
			return null;
		else
		{
			initalContext.setParameters(pbdMethodParameter);
			return initalContext;
		}
	}*/
	

/*	private Context diffContext(Context glbResidueCntx, Context inheritedCntx){
		
		List<PbDMethodParameter> glbParas = glbResidueCntx.getParameters();
		List<PbDMethodParameter> inhParas = inheritedCntx.getParameters();
		
		List<PbDMethodParameter> commonParas = new ArrayList<PbDMethodParameter>();
		Context commonCntx = new Context();
		
		for(int i=0;i<glbParas.size(); i++){
			for(int j=0;j<inhParas.size(); j++){
				if(glbParas.get(i).getName().equals(inhParas.get(j).getName())){
					commonParas.add(inhParas.get(j));
				}
			}
		}
		
		if(commonParas.size() ==0)
			return null;
		else
		{
			commonCntx.setParameters(commonParas);
			return commonCntx;
		}
	}*/
	
	private Context getSetDiffCntx(Context cntx1, Context cntx2){
		
		List<PbDMethodParameter> cntx1Paras = cntx1.getOriginalParameters();
		List<PbDMethodParameter> cntx2Paras = cntx2.getOriginalParameters();
		
		List<PbDMethodParameter> cntxDiff = new ArrayList<PbDMethodParameter>();
		
		boolean common = false;
		
		for(int i=0; i<cntx1Paras.size();i++){
			common = false;
			for(int j=0; j<cntx2Paras.size();j++){
				if(cntx1Paras.get(i).getId()==cntx2Paras.get(j).getId()){
					common=true;
				}
			}
			if(!common){
				cntxDiff.add(cntx1Paras.get(i));
			}
		}
		
		Context diff = new Context();
		diff.setLineNo(-1);
		if(cntxDiff.size()==0)
			diff.setOriginalPbDParameters(null);
		else
			diff.setOriginalPbDParameters(cntxDiff);
		return diff;
	}
	
	/**
	 * Bottom up traversal of summary graph
	 * 
	 * @param pbdMethod
	 * @param currentCaller
	 */
	public void subGraphProcess(PbDMethod pbdMethod, PbDMethod currentCaller)
	{		
		if(pbdMethod.isBoundaryMethod())
		{
			processBoundaryMethod(pbdMethod);
			PbDMethod nextSibling = getNextSibling(pbdMethod);
			if(nextSibling == null)
			{
				subGraphProcess(currentCaller, currentCaller.getCurrentCaller());
			}
			else{
				subGraphProcess(nextSibling, currentCaller);
			}
		}
		boolean status = checkEvaluatedStatusOfChildren(pbdMethod);
		if(status){
			
			processNonBoundaryMethod(pbdMethod);
			
			if(currentCaller != null)
				subGraphProcess(currentCaller, currentCaller.getCurrentCaller());
		}
		PbDMethod child = getNextNonVisitedChild(pbdMethod);
		if(child != null)
			subGraphProcess(child, pbdMethod);
		
	}
	
	public PbDMethod getNextNonVisitedChild(PbDMethod pbdMethod){
		
		List<Callee> callees = pbdMethod.getCallees();
		for(int i=0; i<callees.size(); i++){
			PbDMethod sibling = callees.get(i).getPbDMethod();
			if(!sibling.IsEvaluated())
				return sibling;
		}
		return null;
	}
	
	/**
	 * Report sensitive information leaks by boundary methods.
	 * Sensitive information leaks by the boundary method will be direct leaks.
	 * @param boundaryMethod
	 */
	public void processBoundaryMethod(PbDMethod boundaryMethod){
		if(boundaryMethod.IsEvaluated())
			return;
		List<Sink> bsinks = boundaryMethod.getSinks();
		for(int j=0; j<bsinks.size(); j++){
			reportSink(bsinks.get(j), METHOD_TYPE.BOUNDARY);
		}
		boundaryMethod.setEvaluated(true);
	}
	
	public void processNonBoundaryMethod(PbDMethod nonBoundaryMethod){
		if(nonBoundaryMethod.IsEvaluated())
			return;
		List<Sink> bsinks = nonBoundaryMethod.getSinks();
		for(int j=0; j<bsinks.size(); j++){
			reportSink(bsinks.get(j), METHOD_TYPE.NON_BOUNDARY);
		}
		nonBoundaryMethod.setEvaluated(true);
	}
	
	public PbDMethod getNextSibling(PbDMethod pbdMethod){
		
		List<Callee> callees = pbdMethod.getCallees(); 
				
		for(int i=0; i<callees.size(); i++){
			
			PbDMethod callee = callees.get(i).getPbDMethod();
			
			if(!callee.IsEvaluated()){
				return callee;
			}
		}
				
		return null;
	}
	
	public static void main(String[] args) throws FileNotFoundException{
		
		SQLAlgorithm sqlAlgo = new SQLAlgorithm();
		
		sqlAlgo.startAlgorithm();
				
	}
	
	private void reportSink(Sink sink, METHOD_TYPE methodType){
		
		if(methodType==METHOD_TYPE.BOUNDARY){
			//Process sinks of boundary method
		}
		else if(methodType==METHOD_TYPE.NON_BOUNDARY){
			
			//obtain sink dependency
			List<SinkDependency> sinkDependencies = sink.getSinkDependencies();
			for(int i=0; i<sinkDependencies.size(); i++){
				SinkDependency sinkDependency = sinkDependencies.get(i);
				List<PbDMethodParameter> methodParams = sinkDependency.getDependentMethodParameters();
				for(int j=0; j<methodParams.size(); j++){
					PbDMethodParameter parameter = methodParams.get(j);
					if(parameter.isSensitive()){
						//report that as leak
					}
				}
			}
		}
		else if(methodType==METHOD_TYPE.COMMON){
			
		}
		else{
			//throw unsupported method type exception
		}
	}
	
	/**
	 * Set evaluated status to true if all of its callees are also evaluated
	 * @param pbdMethod
	 */
	private boolean checkEvaluatedStatusOfChildren(PbDMethod pbdMethod){
		
		List<Callee> callees = pbdMethod.getCallees(); 
		
		boolean flag = true;
		
		for(int i=0; i<callees.size(); i++){
			
			PbDMethod callee = callees.get(i).getPbDMethod();
			
			if(!callee.IsEvaluated()){
				flag = false;
			}
		}
		
		pbdMethod.setEvaluated(flag);
		
		return flag;
		
	}
	enum METHOD_TYPE{
		BOUNDARY,
		NON_BOUNDARY,
		COMMON
	}
	
	/*public void evaluateSinkDependency(Sink sink){
		
		List<SinkDependency> lstSinkDeps = sink.getSinkDependencies();
		
		for(int i=0; i<lstSinkDeps.size(); i++){
			
			SinkDependency sinkDependency = lstSinkDeps.get(i);
			PbDMethod depMethod = sinkDependency.getPbDMethod();
			List<PbDMethodParameter> depMethodParas = depMethod.getParameters();
			List<PbDMethodParameter> sinkUseParams = sinkDependency.getDependentMethodParameters();
			Context initialCntx = getInitialContext(depMethodParas, sinkUseParams);
		}
	}
	
	private boolean exploreSubGraph(Context cntx, PbDMethod pbdMethod){
		
		boolean dependency = false;
		
		List<Callee> callees =  pbdMethod.getCallees();
		
		for(int i=0; i<callees.size(); i++){
			
			//this will get inherited context (excluding the one which is getting killed)
			Context inheritedCntx = dbUtils.checkMethodInheritContext(callees.get(i).getPbDMethod(), pbdMethod);
			
			//check whether original contex is propagated into the callee or not
			Context diff = diffContext(cntx, inheritedCntx);
			if(diff != null){
				if(!callees.get(i).getPbDMethod().isBoundaryMethod())
				{
					//sinkDepQueue.add(callees.get(i));
				}
				else
				{
					dependency = true;
					
				}
			}
			if(dependency)
				break;
		}
		if(!dependency && sinkDepQueue.size() > 0){
			PbDMethod queuedPbDMethod = null;//sinkDepQueue.peek();
		}
		return dependency;
	}*/
	
}

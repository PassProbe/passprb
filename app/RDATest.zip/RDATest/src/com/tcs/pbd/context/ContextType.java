package com.tcs.pbd.context;

public enum ContextType {
	inherited,
	killed
}

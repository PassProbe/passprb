package com.tcs.pbd.context;

import java.util.List;

import com.tcs.pbd.resultset.process.PbDMethodParameter;

public class Context {

	private int line_no;
	
	private ContextType type;
	
	private List<PbDMethodParameter> origPbdParameters;
	
	private List<PbDMethodParameter> newPbdParameters;
	
	public int getLineNo() { return line_no; }
	
	public List<PbDMethodParameter> getOriginalParameters() { return origPbdParameters; }
	
	public List<PbDMethodParameter> getNewParameters() { return newPbdParameters; }
	
	public void setLineNo(int lineNo) { this.line_no = lineNo; }
	
	public ContextType getType() { return type; }
	
	public void setOriginalPbDParameters(List<PbDMethodParameter> parameters) { this.origPbdParameters = parameters; }
	
	public void setNewPbDParameters(List<PbDMethodParameter> parameters) { this.newPbdParameters = parameters; }
		
	public String toString(){
		
		if(origPbdParameters == null)
			return "null";
		
		StringBuilder contextString = new StringBuilder();
		
		for(int i=0; i<origPbdParameters.size(); i++){
			contextString.append(origPbdParameters.get(i).getName());
			contextString.append(",");
		}
		
		contextString.append(" :: ");
		
		if(newPbdParameters == null){
			contextString.append("null");
			return contextString.toString();
		}
		
		for(int i=0; i<newPbdParameters.size(); i++){
			contextString.append(newPbdParameters.get(i).getName());
			contextString.append(",");
		}
		
		return contextString.toString();
	}
	
	public void setContextType(ContextType ct){
		this.type = ct;
	}
	
}


package com.tcs.pbd.context;

public enum VariableState {
	
	alive,
	inUse,
	killed,
	undecided

}

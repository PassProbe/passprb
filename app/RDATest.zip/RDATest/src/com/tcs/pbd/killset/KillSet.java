package com.tcs.pbd.killset;

import com.tcs.pbd.resultset.process.PbDMethodParameter;

public class KillSet {

	private int line_no;
	
	private ParameterType type;
	
	private PbDMethodParameter parameter;
	
	public int getLineNo() {  return line_no; }
	
	public ParameterType getParameterType() { return type; }
	
	public PbDMethodParameter getParameter() { return parameter; }
	
	public void setLineNo(int lineNo) { this.line_no = lineNo; }
	
	public void setParameterType(ParameterType type) { this.type = type; }
	
	public void setPbDMethodParameter(PbDMethodParameter parameter) { this.parameter = parameter; }
	
}



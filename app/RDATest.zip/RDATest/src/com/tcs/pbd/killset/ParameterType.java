package com.tcs.pbd.killset;

public enum ParameterType {

	PRIMITIVE,
	REFERENCE
	
}

package com.tcs.method.test;

import java.util.LinkedList;
import java.util.Queue;

import com.tcs.pbd.resultset.process.PbDMethod;

public class EqualTest {
	
	static Queue<PbDMethod> queueMethods = new LinkedList<PbDMethod>();
	
	static int count = 0;
	
	public static void main(String[] args){
		
		EqualTest e1 = new EqualTest();
		
		PbDMethod p1 = e1.createPbDInstance();
		queueMethods.add(p1);
		PbDMethod p2 = e1.createPbDInstance();
		if(queueMethods.contains(p2))
			System.out.println("Hurray it contains ...");
		System.out.println(p1.equals(p2));
		
	}
	
	public PbDMethod createPbDInstance(){
		
		PbDMethod i1 = new PbDMethod();
		i1.setId(1);
		
		return i1;
	}

}

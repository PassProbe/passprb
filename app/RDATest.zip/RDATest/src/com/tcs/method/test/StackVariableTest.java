package com.tcs.method.test;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class StackVariableTest {

	int x;
	int y;
	
	String test;
	
	public void firstMethod(int a, int b){
		a = 35;
		b = 45;
	}
	public void secondMethod(int c, int d){
		c = 50;
		d = 60;
	}
	
	public void thirdMethod(){
		this.x = 40;
		this.y = 50;
	}
	
	public void fourthMethod(String text){
		text = "Hello";
	}
	
	public void fifthMethod(String passed){
		
		this.test = passed;
		
	}
	
	public void sixMethod(StackVariableTest temp){
		temp.x = 100;
		temp.y = 200;
		temp.test = "second obj";
	}
	
	public static void main(String[] args){
		
		StackVariableTest obj = new StackVariableTest();
		obj.x = 10;
		obj.y = 20;
		
		int p = -1;
		int q = -2;
		
		obj.firstMethod(p, q);
		
		System.out.println(p + " " + q);
		
		obj.thirdMethod();
		
		System.out.println(obj.x + " " + obj.y);
		
		String text = new String("hi");
		
		
		obj.fourthMethod(text);
		
		System.out.println(text);
		
		obj.test ="Before method call";
		
		obj.fifthMethod("after method call");
		
		System.out.println(obj.test);
		
		StackVariableTest obj2 = new StackVariableTest();
		
		obj.sixMethod(obj2);
		
		System.out.println(obj2.x + " " + obj2.y + " " + obj2.test);
		
		obj.test();
	}
	
	public void test(){
		
		String[] strings = {"A", "B", "C"};
		
		StringBuilder strBuilder = new StringBuilder();
		
		for(int j=0; j<strings.length; j++){
			strBuilder.append(strings[j] + ",");
		}
		
		System.out.println(strBuilder.substring(0, strBuilder.length()-1));
	}
}

package com.tcs.method.test;

public class TestTree {
	
	public static void main(String args[]){
		
		long parameter = 1003;
		
		TreeNode root = new TreeNode(parameter);
		long[] values = new long[5];
		values[0] = 1001;
		values[1] = 1002;
		values[2] = 1003;
		values[3] = 1004;
		values[4] = 1005;
		
		root.createChildren(5, values);
		
		System.out.println(root.getChild(3).getValue());
		
	}

}


class TreeNode
{
	private long value;
	private int count;
	TreeNode children[];
	
	public long getValue() { return value; }
		
	public TreeNode(long value){
		this.value = value;
	}
	
	public void createChildren(int cnt, long[] values){
		this.count = cnt;
		children = new TreeNode[cnt];
		for(int i=0; i<cnt; i++){
			children[i] = new TreeNode(values[i]);
		}
	}
	
	public TreeNode getChild(int index){
		return children[index];
	}
}
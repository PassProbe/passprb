/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: UserRequestEditFormAction.java,v 1.2 2005/10/04 03:08:22 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.jugjobs.form.EditRequestForm;
import org.jugjobs.model.PostingsList;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserRequestEditFormAction extends CommonAction {

	  public ActionForward execute(ActionMapping mapping, ActionForm form,
	      HttpServletRequest request, HttpServletResponse response)
	      throws Exception
	  {
	    String buttonValue = request.getParameter("button");
	    if(buttonValue == null){
	      throw new Exception("buttonValue null");
	    }
	    if(buttonValue.equals(ADD_BUTTON_VALUE)){
	      logger.log("In UserRequestEditFormAction, " +
	              "A new-job entry form has has been requested.");
	      request.setAttribute("bodyJSP","WEB-INF/pages/enterEditDelete.jsp");
	      return mapping.findForward("jugTemplate");
	    }
	    if(buttonValue.equals(USER_EDIT_BUTTON_VALUE)){
	      String intString = ((EditRequestForm)form).getJob_number();
	      if(intString == null){
	        throw new NullPointerException("Job number parameter not found.");
	      }
	      PostingsList modelBean = getModelBean(servlet);
	      int job_number = Integer.parseInt(intString);
	      String submittedPassword = ((EditRequestForm)form).getPosting_password();
	      String logString = " in UserRequestEditFormAction, " +
	          "a request to edit job number "+job_number+" with password "+
	          submittedPassword;
	      if(modelBean.passPassword(job_number, submittedPassword)){
	        HttpSession session = request.getSession();
	        session.setAttribute(AUTHENTICATED_FOR_JOB_NO, intString);
	        request.setAttribute("jobBean", modelBean.getPosting(job_number));
	        logger.log("ALLOWED" +logString); 
	        request.setAttribute("bodyJSP","WEB-INF/pages/enterEditDelete.jsp");
	        return mapping.findForward("jugTemplate");  
	      }else{
	        logger.log("DENIED" +logString);    
	        request.setAttribute("bodyJSP","WEB-INF/pages/userLoginFail.html");
	        return mapping.findForward("jugTemplate");    
	      }
	    }
	    //we should not get here
	    throw new Exception("Unexpected button value \""+buttonValue+"\"");
	  }
	}

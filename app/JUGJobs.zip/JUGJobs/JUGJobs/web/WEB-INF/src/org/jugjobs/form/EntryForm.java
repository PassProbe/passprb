/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: EntryForm.java,v 1.3 2005/10/04 03:09:23 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.form;

import org.apache.struts.action.ActionForm;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EntryForm extends ActionForm {
	
    private String job_number;
    private String job_title;
    private String employer_name;
    private String employer_url;
    private String job_desc;
    private String contact_name;
    private String contact_info;
    private String posting_password;
    private String admin_contact_info;
    private String last_edit_date;
    


    public String getJob_number() {
      return (job_number);
    }

    public void setJob_number(String s) {
        job_number = s;
    }

    public String getJob_title() {
      return (job_title);
    }

    public void setJob_title(String s) {
        job_title = s;
    }
    
    public String getEmployer_name() {
      return (employer_name);
    }

    public void setEmployer_name(String s) {
        employer_name = s;
    }
    
    public String getEmployer_url() {
      return (employer_url);
    }

    public void setEmployer_url(String s) {
        employer_url = s;
    }
    
    public String getJob_desc() {
      return (job_desc);
    }

    public void setJob_desc(String s) {
        job_desc = s;
    }
    
    public String getContact_name() {
      return (contact_name);
    }

    public void setContact_name(String s) {
        contact_name = s;
    }
    
    public String getContact_info() {
      return (contact_info);
    }

    public void setContact_info(String s) {
        contact_info = s;
    }
    
    public String getPosting_password() {
      return (posting_password);
    }

    public void setPosting_password(String s) {
        posting_password = s;
    }

    public String getAdmin_contact_info() {
      return (admin_contact_info);
    }

    public void setAdmin_contact_info(String s) {
        admin_contact_info = s;
    }
    
    public String getLast_edit_date() {
      return (last_edit_date);
    }

    public void setLast_edit_date(String s) {
        last_edit_date = s;
    }
}

/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: PostingsList.java,v 1.3 2005/10/04 03:10:06 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.model;


import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.jugjobs.form.PostingFormBean;


/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class PostingsList {

	  private static PostingsList loneInstance;
	  private ArrayList postingsList;
	  private boolean postingsListCurrent;
	  
	  public PostingsList()throws InstantiationException{
	    if (loneInstance != null){
	      throw new InstantiationException(
	                  "Attempt to create second instance of PostingsList.");
	    }
	    loneInstance = this;
	  }

	  public boolean passPassword(int jobNumber, String submittedPassword)
	        throws SQLException{
	   String realPassword = Database.getPosting(jobNumber).getPosting_password();
	   return realPassword.equals(submittedPassword);
	  }
	  
	  public ArrayList getPostingsList(){
	    if(!postingsListCurrent){
	      synchronized(this){
	        try {
				postingsList = Database.getAllPostings();
				postingsListCurrent = true;
			} catch (SQLException e) {
				PostingFormBean pfb=new PostingFormBean();
				pfb.setErrorMessage(e.getMessage());
				pfb.setErrorInfo(e.toString());
				ArrayList al = new ArrayList();
				al.add(pfb);
				return al;
			}
	      }
	    }
	    return postingsList;
	  }
	  
	  public synchronized PostingFormBean getPosting(int jobNumber) 
	              throws SQLException{
	    return Database.getPosting(jobNumber);
	  }
	  
	  public synchronized void insertPosting(PostingFormBean posting) 
	              throws SQLException{
	    Connection connection = Database.connectToDb();
	    try{
	      postingsListCurrent = false;
	      Database.insertPosting(connection, posting);
	    }finally{
	      connection.close();
	    }
	  }
	  
	  public synchronized void deletePosting(int jobNumber) throws SQLException{
	    Connection connection = Database.connectToDb();
	    try{
	      postingsListCurrent = false;
	      Database.deletePosting(connection, jobNumber);
	    }finally{
	      connection.close();
	    }
	  }

	  public synchronized void replacePosting(PostingFormBean posting)
	              throws SQLException{
	    Connection connection = Database.connectToDb();
	    try{
	      postingsListCurrent = false;
	      int jobNumber = Integer.parseInt(posting.getJob_number());
	      Database.deletePosting(connection, jobNumber);
	      Database.insertPosting(connection, posting);
	    }finally{
	      connection.close();
	    }
	  }
	}
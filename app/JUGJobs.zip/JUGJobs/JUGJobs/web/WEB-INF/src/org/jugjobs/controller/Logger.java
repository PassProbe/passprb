/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: Logger.java,v 1.2 2005/10/04 03:08:46 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.struts.action.ActionServlet;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Logger {
	  
	  private LogFileWriter logFileWriter;
	  private SimpleDateFormat dateFormat =
	            new SimpleDateFormat("DDD:HH:mm:ss.SSS");
	  
	  Logger(ActionServlet mamaServlet)throws IOException{
	    String logFileDirectory = 
	      mamaServlet.getServletContext().getRealPath("WEB-INF/logs/");
	    logFileWriter = new LogFileWriter(logFileDirectory);
	  }
	  
	  public String log(String report){
	    String dateString;
	    Date nowDate = new Date();
	    synchronized (dateFormat){
	      dateString = dateFormat.format(nowDate);
	    }
	    String reportString = dateString + " " + report;
	    logFileWriter.writeln(reportString);
	    return dateString;
	  }
	  public String log(String report, Throwable tooty){
	    if (report.length()>0) report += "\r\n";
	    StringWriter sw = new StringWriter();
	    tooty.printStackTrace(new PrintWriter(sw));
	    return log(report +  sw.toString());
	  }
	  public String log(Throwable tooty){
	    return log("", tooty);
	  }
	  
	  void close(){
	    logFileWriter.close();
	  }
	    
	}

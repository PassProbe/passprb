/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: Constants.java,v 1.2 2005/10/04 03:08:46 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.controller;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface Constants {

	  String
	    CANCEL_BUTTON_VALUE = "CANCEL",
	    SAVE_BUTTON_VALUE = "SAVE",
	    UPDATE_BUTTON_VALUE = "UPDATE THIS JOB POSTING",
	    DELETE_BUTTON_VALUE = "DELETE THIS JOB POSTING",
	    ADMIN_LOGOUT_BUTTON_VALUE = "ADMINISTRATOR LOG OUT",
	    ADMIN_EDIT_BUTTON_VALUE = "EDIT OR DELETE THIS JOB",
	    USER_EDIT_BUTTON_VALUE = "EDIT OR DELETE",
	    ADD_BUTTON_VALUE = "CLICK HERE",
	    ADMIN_LOGGED_IN = "ADMIN_LOGGED_IN",
	    AUTHENTICATED_FOR_JOB_NO = "AUTHENTICATED_FOR_JOB_NO";
}

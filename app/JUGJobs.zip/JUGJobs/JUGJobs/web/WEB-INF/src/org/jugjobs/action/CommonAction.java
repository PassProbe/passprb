/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: CommonAction.java,v 1.2 2005/10/04 03:08:22 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.action;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.jugjobs.controller.Constants;
import org.jugjobs.controller.JobsServlet;
import org.jugjobs.controller.Logger;
import org.jugjobs.model.PostingsList;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CommonAction extends Action implements Constants{
	  
	  static Logger logger = JobsServlet.instance.logger;
	  
	  static PostingsList getModelBean(HttpServlet servlet)
	                                      throws InstantiationException{
	    ServletContext context = servlet.getServletContext();
	    PostingsList modelBean = (PostingsList)context.getAttribute("modelBean");
	    if (modelBean == null){
	      modelBean = new PostingsList();
	      context.setAttribute("modelBean",modelBean);
	    }
	    return modelBean;
	  }
	  	    
	  static boolean isUserAuthorizedForJob(HttpSession session, 
	          int jobNumber){
	    if(isAdministratorAuthorized(session)){
	      return true;
	    }
	    boolean returnValue = false;
	    String authenticatedJobNumber = 
	      (String)session.getAttribute(AUTHENTICATED_FOR_JOB_NO);
	    if(authenticatedJobNumber != null){
	      returnValue = jobNumber == Integer.parseInt(authenticatedJobNumber);
	    }   
	    if(returnValue == false){
	      logger.log("CommonAction.isUserAuthorizedForJob() " +
	          "failed attempting to access jobNumber "+jobNumber+", but " +
	          "AUTHENTICATED_FOR_JOB_NO "+authenticatedJobNumber);
	    }
	    return returnValue;
	  }


	  static boolean isAdministratorAuthorized(HttpSession session){
	    return ADMIN_LOGGED_IN.equals(session.getAttribute(ADMIN_LOGGED_IN));
	  }
	}

/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: ProcessEditFormAction.java,v 1.2 2005/10/04 03:08:22 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.jugjobs.form.PostingFormBean;
import org.jugjobs.model.PostingsList;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProcessEditFormAction extends CommonAction {

	  public ActionForward execute(ActionMapping mapping, ActionForm form,
	      HttpServletRequest request, HttpServletResponse response)
	      throws Exception
	  {
	    PostingsList modelBean = getModelBean(servlet);
	    String buttonValue = request.getParameter("button");
	    if(buttonValue == null){
	      throw new Exception("buttonValue null");
	    }
	    if(buttonValue.equals(CANCEL_BUTTON_VALUE)){
	      logger.log("In ProcessEditFormAction, " +
	          "Editing of job cancelled.");
	      return mapping.findForward("jobsPage");
	    }
	    PostingFormBean entryForm = (PostingFormBean)form;
	    if(buttonValue.equals(UPDATE_BUTTON_VALUE) || 
	       buttonValue.equals(DELETE_BUTTON_VALUE))
	    {
	      int jobNumber = Integer.parseInt(entryForm.getJob_number());
	      HttpSession session = request.getSession();
	      if(!isUserAuthorizedForJob(session, jobNumber))
	      {
	        logger.log("In ProcessEditFormAction, " +
	        "user not authorized, maybe a timeout.");
	        request.setAttribute("bodyJSP","WEB-INF/pages/authTimeout.html");
	        return mapping.findForward("jugTemplate");
	      }
	      if(buttonValue.equals(DELETE_BUTTON_VALUE)){
	        logger.log("In ProcessEditFormAction, " +
	              "Delete job number " + jobNumber + " has been requested.");
	        request.setAttribute("jobBean",modelBean.getPosting(jobNumber));
	        request.setAttribute("bodyJSP","WEB-INF/pages/delete.jsp");
	        return mapping.findForward("jugTemplate");
	      }else{// must be UPDATE_BUTTON_VALUE
	        logger.log("In ProcessEditFormAction, " +
	            "Replacing (Updating) job number " + jobNumber + 
	            " has been requested.");
	        modelBean.replacePosting(entryForm);
	        session.removeAttribute(AUTHENTICATED_FOR_JOB_NO);
	        return mapping.findForward("jobsPage");
	      }
	    }
	    if(buttonValue.equals(SAVE_BUTTON_VALUE)){
	      logger.log("In ProcessEditFormAction, " +
	          "Entering a new job has been requested.");
	      modelBean.insertPosting(entryForm);
	      return mapping.findForward("jobsPage");
	    }
	    //we should not get here
	    throw new Exception("Unexpected button value \""+buttonValue+"\"");
	  }
	}

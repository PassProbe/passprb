/* 
 * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups
 * $Id: JobsServlet.java,v 1.2 2005/10/04 03:08:46 biglee Exp $
 * 
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the JUGJobs project.
 *
 * The Initial Developers of the Original Code are the members of the Triangle
 * Java User's Group in the RTP area of North Carolina.
 * Portions created by the Initial Developer are Copyright (C) 2005
 * the Initial Developers. All Rights Reserved.
 *
 * Contributor(s):
 *
 * ***** END LICENSE BLOCK ***** 
 */
package org.jugjobs.controller;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.struts.action.ActionServlet;

/**
 * @author BigLee
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class JobsServlet extends ActionServlet {
	  public static JobsServlet instance;
	  public Logger logger;
	  
	  public void init() throws ServletException {
	    super.init();
	    if(instance == null){
	      instance = this;
	    }else{
	      throw new ServletException("Attempt to create second instance.");
	    }
	    try{
	      logger = new Logger(this);      
	    }catch (IOException e){
	      throw new ServletException("problem creating logger", e);
	    }
	  }
	  
	  public void destroy() {
	    logger.log("executing JobsServlet.destroy()");
	    logger.close();
	    super.destroy();
	  }
	}

package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import org.jugjobs.controller.Constants;

public class enterEditDelete_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_present_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_notPresent_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_form_method_action;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_submit_value_property_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_text_size_property_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_text_size_property_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_textarea_rows_property_name_cols_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_textarea_rows_property_cols_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_hidden_property_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_reset_value_nobody;

  public enterEditDelete_jsp() {
    _jspx_tagPool_logic_present_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_notPresent_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_form_method_action = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_submit_value_property_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_text_size_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_text_size_property_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_textarea_rows_property_name_cols_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_textarea_rows_property_cols_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_hidden_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_reset_value_nobody = new org.apache.jasper.runtime.TagHandlerPool();
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspDestroy() {
    _jspx_tagPool_logic_present_name.release();
    _jspx_tagPool_logic_notPresent_name.release();
    _jspx_tagPool_html_form_method_action.release();
    _jspx_tagPool_html_submit_value_property_nobody.release();
    _jspx_tagPool_html_text_size_property_name_nobody.release();
    _jspx_tagPool_html_text_size_property_nobody.release();
    _jspx_tagPool_html_textarea_rows_property_name_cols_nobody.release();
    _jspx_tagPool_html_textarea_rows_property_cols_nobody.release();
    _jspx_tagPool_html_hidden_property_name_nobody.release();
    _jspx_tagPool_html_reset_value_nobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n/* \r\n * JUGJobs - A Jobs Posting Application for Java Users Groups and Other Groups\r\n * $Id: $\r\n * \r\n * ***** BEGIN LICENSE BLOCK *****\r\n * Version: MPL 1.1\r\n *\r\n * The contents of this file are subject to the Mozilla Public License Version\r\n * 1.1 (the \"License\"); you may not use this file except in compliance with\r\n * the License. You may obtain a copy of the License at\r\n * http://www.mozilla.org/MPL/\r\n *\r\n * Software distributed under the License is distributed on an \"AS IS\" basis,\r\n * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License\r\n * for the specific language governing rights and limitations under the\r\n * License.\r\n *\r\n * The Original Code is the JUGJobs project.\r\n *\r\n * The Initial Developers of the Original Code are the members of the Triangle\r\n * Java User's Group in the RTP area of North Carolina.\r\n * Portions created by the Initial Developer are Copyright (C) 2005\r\n * the Initial Developers. All Rights Reserved.\r\n *\r\n * Contributor(s):\r\n *\r\n * ***** END LICENSE BLOCK ***** \r\n");
      out.write(" */\r\n -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">\r\n");
      out.write("<tr>\r\n  ");
      out.write("<td valign=\"top\">\r\n    \r\n    ");
      out.write("<p class=\"header4\" align=\"center\">\r\n      ");
      if (_jspx_meth_logic_present_0(pageContext))
        return;
      out.write("\r\n      ");
      if (_jspx_meth_logic_notPresent_0(pageContext))
        return;
      out.write("\r\n    ");
      out.write("</p>\r\n    \r\n    ");
      /* ----  html:form ---- */
      org.apache.struts.taglib.html.FormTag _jspx_th_html_form_0 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_method_action.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_form_0.setPageContext(pageContext);
      _jspx_th_html_form_0.setParent(null);
      _jspx_th_html_form_0.setAction("addEdit.do");
      _jspx_th_html_form_0.setMethod("POST");
      int _jspx_eval_html_form_0 = _jspx_th_html_form_0.doStartTag();
      if (_jspx_eval_html_form_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n      \r\n      ");
          out.write("<table border=\"1\" cellpadding=\"4\" cellspacing=\"0\">\r\n      \r\n      ");
          /* ----  logic:present ---- */
          org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_1 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
          _jspx_th_logic_present_1.setPageContext(pageContext);
          _jspx_th_logic_present_1.setParent(_jspx_th_html_form_0);
          _jspx_th_logic_present_1.setName("jobBean");
          int _jspx_eval_logic_present_1 = _jspx_th_logic_present_1.doStartTag();
          if (_jspx_eval_logic_present_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n      ");
              out.write("<tr>  ");
              out.write("<!-- delete this job button -->\r\n        ");
              out.write("<td valign=\"middle\" align=\"center\" colspan=\"2\">\r\n          ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_0 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_0.setPageContext(pageContext);
              _jspx_th_html_submit_0.setParent(_jspx_th_logic_present_1);
              _jspx_th_html_submit_0.setValue( Constants.DELETE_BUTTON_VALUE);
              _jspx_th_html_submit_0.setProperty("button");
              int _jspx_eval_html_submit_0 = _jspx_th_html_submit_0.doStartTag();
              if (_jspx_th_html_submit_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_0);
              out.write("\r\n        ");
              out.write("</td>\r\n      ");
              out.write("</tr>\r\n      ");
              int evalDoAfterBody = _jspx_th_logic_present_1.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_present_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_1);
          out.write("\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Company name -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" nowrap class=\"header2\">Company name:\r\n        ");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_2(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_1(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Company URL -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Company URL:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          http://\r\n          ");
          if (_jspx_meth_logic_present_3(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_2(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          out.write("<span class=\"nav\">\r\n            ");
          out.write("<br>(optional: if given your company name will link to this URL)\r\n          ");
          out.write("</span>\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Job Title -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Job Title:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_4(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_3(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Contact Name -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Contact Name:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_5(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_4(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          out.write("<span class=\"nav\">\r\n            ");
          out.write("<br>(the representative whom applicants should contact)\r\n          ");
          out.write("</span>.\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Contact Information -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Contact Information:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_6(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_5(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          out.write("<span class=\"nav\">\r\n            ");
          out.write("<br>(phone number, address, or email address for applicants to use)\r\n          ");
          out.write("</span>\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Posting Password -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Posting Password:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_7(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_6(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          out.write("<br>");
          out.write("<span class=\"nav\">\r\n            (required for you to come back to edit or delete this job entry)");
          out.write("</span>\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Admin Contact Point -->\r\n        ");
          out.write("<td valign=\"middle\" align=\"right\" class=\"header2\">Admin Contact Point:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_8(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_7(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          out.write("<span class=\"nav\">\r\n            ");
          out.write("<br>(in case we at TriJUG need to contact you about this posing \r\n            ");
          out.write("<br> &#151; this will not be made public)\r\n          ");
          out.write("</span>\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Job Description -->\r\n        ");
          out.write("<td valign=\"top\" align=\"right\" class=\"header2\">Job Description:");
          out.write("</td>\r\n        ");
          out.write("<td valign=\"middle\" align=\"left\">\r\n          ");
          if (_jspx_meth_logic_present_9(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          ");
          if (_jspx_meth_logic_notPresent_8(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      \r\n      ");
          out.write("<tr>  ");
          out.write("<!-- Control Buttons at bottom-->\r\n        ");
          out.write("<td valign=\"middle\" align=\"center\" colspan=\"2\">\r\n          ");
          /* ----  logic:present ---- */
          org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_10 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
          _jspx_th_logic_present_10.setPageContext(pageContext);
          _jspx_th_logic_present_10.setParent(_jspx_th_html_form_0);
          _jspx_th_logic_present_10.setName("jobBean");
          int _jspx_eval_logic_present_10 = _jspx_th_logic_present_10.doStartTag();
          if (_jspx_eval_logic_present_10 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n            ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_1 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_1.setPageContext(pageContext);
              _jspx_th_html_submit_1.setParent(_jspx_th_logic_present_10);
              _jspx_th_html_submit_1.setValue( Constants.UPDATE_BUTTON_VALUE);
              _jspx_th_html_submit_1.setProperty("button");
              int _jspx_eval_html_submit_1 = _jspx_th_html_submit_1.doStartTag();
              if (_jspx_th_html_submit_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_1);
              out.write("\r\n            ");
              if (_jspx_meth_html_hidden_0(_jspx_th_logic_present_10, pageContext))
                return;
              out.write("\r\n          ");
              int evalDoAfterBody = _jspx_th_logic_present_10.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_present_10.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_10);
          out.write("\r\n          ");
          /* ----  logic:notPresent ---- */
          org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_9 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
          _jspx_th_logic_notPresent_9.setPageContext(pageContext);
          _jspx_th_logic_notPresent_9.setParent(_jspx_th_html_form_0);
          _jspx_th_logic_notPresent_9.setName("jobBean");
          int _jspx_eval_logic_notPresent_9 = _jspx_th_logic_notPresent_9.doStartTag();
          if (_jspx_eval_logic_notPresent_9 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n            ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_2 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_2.setPageContext(pageContext);
              _jspx_th_html_submit_2.setParent(_jspx_th_logic_notPresent_9);
              _jspx_th_html_submit_2.setValue( Constants.SAVE_BUTTON_VALUE);
              _jspx_th_html_submit_2.setProperty("button");
              int _jspx_eval_html_submit_2 = _jspx_th_html_submit_2.doStartTag();
              if (_jspx_th_html_submit_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_2);
              out.write("\r\n          ");
              int evalDoAfterBody = _jspx_th_logic_notPresent_9.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_notPresent_9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_9);
          out.write("\r\n          &nbsp;\r\n          ");
          if (_jspx_meth_html_reset_0(_jspx_th_html_form_0, pageContext))
            return;
          out.write("\r\n          &nbsp;\r\n          ");
          /* ----  html:submit ---- */
          org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_3 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
          _jspx_th_html_submit_3.setPageContext(pageContext);
          _jspx_th_html_submit_3.setParent(_jspx_th_html_form_0);
          _jspx_th_html_submit_3.setValue( Constants.CANCEL_BUTTON_VALUE);
          _jspx_th_html_submit_3.setProperty("button");
          int _jspx_eval_html_submit_3 = _jspx_th_html_submit_3.doStartTag();
          if (_jspx_th_html_submit_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_3);
          out.write("\r\n        ");
          out.write("</td>\r\n      ");
          out.write("</tr>\r\n      ");
          out.write("</table>\r\n    ");
          int evalDoAfterBody = _jspx_th_html_form_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_form_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_html_form_method_action.reuse(_jspx_th_html_form_0);
      out.write("\r\n    \r\n  ");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }

  private boolean _jspx_meth_logic_present_0(javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_0 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_0.setPageContext(pageContext);
    _jspx_th_logic_present_0.setParent(null);
    _jspx_th_logic_present_0.setName("jobBean");
    int _jspx_eval_logic_present_0 = _jspx_th_logic_present_0.doStartTag();
    if (_jspx_eval_logic_present_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n        Edit a Current Job Posting\r\n      ");
        int evalDoAfterBody = _jspx_th_logic_present_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_0);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_0(javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_0 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_0.setPageContext(pageContext);
    _jspx_th_logic_notPresent_0.setParent(null);
    _jspx_th_logic_notPresent_0.setName("jobBean");
    int _jspx_eval_logic_notPresent_0 = _jspx_th_logic_notPresent_0.doStartTag();
    if (_jspx_eval_logic_notPresent_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n        Enter a New Job Posting\r\n      ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_0);
    return false;
  }

  private boolean _jspx_meth_logic_present_2(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_2 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_2.setPageContext(pageContext);
    _jspx_th_logic_present_2.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_2.setName("jobBean");
    int _jspx_eval_logic_present_2 = _jspx_th_logic_present_2.doStartTag();
    if (_jspx_eval_logic_present_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_0(_jspx_th_logic_present_2, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_2);
    return false;
  }

  private boolean _jspx_meth_html_text_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_2, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_0 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_0.setPageContext(pageContext);
    _jspx_th_html_text_0.setParent(_jspx_th_logic_present_2);
    _jspx_th_html_text_0.setProperty("employer_name");
    _jspx_th_html_text_0.setName("jobBean");
    _jspx_th_html_text_0.setSize("36");
    int _jspx_eval_html_text_0 = _jspx_th_html_text_0.doStartTag();
    if (_jspx_th_html_text_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_0);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_1(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_1 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_1.setPageContext(pageContext);
    _jspx_th_logic_notPresent_1.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_1.setName("jobBean");
    int _jspx_eval_logic_notPresent_1 = _jspx_th_logic_notPresent_1.doStartTag();
    if (_jspx_eval_logic_notPresent_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_1(_jspx_th_logic_notPresent_1, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_1);
    return false;
  }

  private boolean _jspx_meth_html_text_1(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_1, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_1 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_1.setPageContext(pageContext);
    _jspx_th_html_text_1.setParent(_jspx_th_logic_notPresent_1);
    _jspx_th_html_text_1.setProperty("employer_name");
    _jspx_th_html_text_1.setSize("36");
    int _jspx_eval_html_text_1 = _jspx_th_html_text_1.doStartTag();
    if (_jspx_th_html_text_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_1);
    return false;
  }

  private boolean _jspx_meth_logic_present_3(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_3 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_3.setPageContext(pageContext);
    _jspx_th_logic_present_3.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_3.setName("jobBean");
    int _jspx_eval_logic_present_3 = _jspx_th_logic_present_3.doStartTag();
    if (_jspx_eval_logic_present_3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_2(_jspx_th_logic_present_3, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_3.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_3);
    return false;
  }

  private boolean _jspx_meth_html_text_2(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_3, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_2 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_2.setPageContext(pageContext);
    _jspx_th_html_text_2.setParent(_jspx_th_logic_present_3);
    _jspx_th_html_text_2.setProperty("employer_url");
    _jspx_th_html_text_2.setName("jobBean");
    _jspx_th_html_text_2.setSize("36");
    int _jspx_eval_html_text_2 = _jspx_th_html_text_2.doStartTag();
    if (_jspx_th_html_text_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_2);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_2(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_2 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_2.setPageContext(pageContext);
    _jspx_th_logic_notPresent_2.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_2.setName("jobBean");
    int _jspx_eval_logic_notPresent_2 = _jspx_th_logic_notPresent_2.doStartTag();
    if (_jspx_eval_logic_notPresent_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_3(_jspx_th_logic_notPresent_2, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_2);
    return false;
  }

  private boolean _jspx_meth_html_text_3(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_2, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_3 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_3.setPageContext(pageContext);
    _jspx_th_html_text_3.setParent(_jspx_th_logic_notPresent_2);
    _jspx_th_html_text_3.setProperty("employer_url");
    _jspx_th_html_text_3.setSize("36");
    int _jspx_eval_html_text_3 = _jspx_th_html_text_3.doStartTag();
    if (_jspx_th_html_text_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_3);
    return false;
  }

  private boolean _jspx_meth_logic_present_4(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_4 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_4.setPageContext(pageContext);
    _jspx_th_logic_present_4.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_4.setName("jobBean");
    int _jspx_eval_logic_present_4 = _jspx_th_logic_present_4.doStartTag();
    if (_jspx_eval_logic_present_4 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_4(_jspx_th_logic_present_4, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_4.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_4);
    return false;
  }

  private boolean _jspx_meth_html_text_4(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_4, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_4 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_4.setPageContext(pageContext);
    _jspx_th_html_text_4.setParent(_jspx_th_logic_present_4);
    _jspx_th_html_text_4.setProperty("job_title");
    _jspx_th_html_text_4.setName("jobBean");
    _jspx_th_html_text_4.setSize("36");
    int _jspx_eval_html_text_4 = _jspx_th_html_text_4.doStartTag();
    if (_jspx_th_html_text_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_4);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_3(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_3 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_3.setPageContext(pageContext);
    _jspx_th_logic_notPresent_3.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_3.setName("jobBean");
    int _jspx_eval_logic_notPresent_3 = _jspx_th_logic_notPresent_3.doStartTag();
    if (_jspx_eval_logic_notPresent_3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_5(_jspx_th_logic_notPresent_3, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_3.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_3);
    return false;
  }

  private boolean _jspx_meth_html_text_5(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_3, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_5 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_5.setPageContext(pageContext);
    _jspx_th_html_text_5.setParent(_jspx_th_logic_notPresent_3);
    _jspx_th_html_text_5.setProperty("job_title");
    _jspx_th_html_text_5.setSize("36");
    int _jspx_eval_html_text_5 = _jspx_th_html_text_5.doStartTag();
    if (_jspx_th_html_text_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_5);
    return false;
  }

  private boolean _jspx_meth_logic_present_5(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_5 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_5.setPageContext(pageContext);
    _jspx_th_logic_present_5.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_5.setName("jobBean");
    int _jspx_eval_logic_present_5 = _jspx_th_logic_present_5.doStartTag();
    if (_jspx_eval_logic_present_5 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_6(_jspx_th_logic_present_5, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_5.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_5);
    return false;
  }

  private boolean _jspx_meth_html_text_6(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_5, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_6 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_6.setPageContext(pageContext);
    _jspx_th_html_text_6.setParent(_jspx_th_logic_present_5);
    _jspx_th_html_text_6.setProperty("contact_name");
    _jspx_th_html_text_6.setName("jobBean");
    _jspx_th_html_text_6.setSize("36");
    int _jspx_eval_html_text_6 = _jspx_th_html_text_6.doStartTag();
    if (_jspx_th_html_text_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_6);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_4(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_4 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_4.setPageContext(pageContext);
    _jspx_th_logic_notPresent_4.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_4.setName("jobBean");
    int _jspx_eval_logic_notPresent_4 = _jspx_th_logic_notPresent_4.doStartTag();
    if (_jspx_eval_logic_notPresent_4 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_7(_jspx_th_logic_notPresent_4, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_4.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_4);
    return false;
  }

  private boolean _jspx_meth_html_text_7(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_4, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_7 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_7.setPageContext(pageContext);
    _jspx_th_html_text_7.setParent(_jspx_th_logic_notPresent_4);
    _jspx_th_html_text_7.setProperty("contact_name");
    _jspx_th_html_text_7.setSize("36");
    int _jspx_eval_html_text_7 = _jspx_th_html_text_7.doStartTag();
    if (_jspx_th_html_text_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_7);
    return false;
  }

  private boolean _jspx_meth_logic_present_6(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_6 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_6.setPageContext(pageContext);
    _jspx_th_logic_present_6.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_6.setName("jobBean");
    int _jspx_eval_logic_present_6 = _jspx_th_logic_present_6.doStartTag();
    if (_jspx_eval_logic_present_6 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_8(_jspx_th_logic_present_6, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_6.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_6);
    return false;
  }

  private boolean _jspx_meth_html_text_8(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_6, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_8 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_8.setPageContext(pageContext);
    _jspx_th_html_text_8.setParent(_jspx_th_logic_present_6);
    _jspx_th_html_text_8.setProperty("contact_info");
    _jspx_th_html_text_8.setName("jobBean");
    _jspx_th_html_text_8.setSize("36");
    int _jspx_eval_html_text_8 = _jspx_th_html_text_8.doStartTag();
    if (_jspx_th_html_text_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_8);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_5(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_5 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_5.setPageContext(pageContext);
    _jspx_th_logic_notPresent_5.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_5.setName("jobBean");
    int _jspx_eval_logic_notPresent_5 = _jspx_th_logic_notPresent_5.doStartTag();
    if (_jspx_eval_logic_notPresent_5 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_9(_jspx_th_logic_notPresent_5, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_5.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_5);
    return false;
  }

  private boolean _jspx_meth_html_text_9(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_5, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_9 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_9.setPageContext(pageContext);
    _jspx_th_html_text_9.setParent(_jspx_th_logic_notPresent_5);
    _jspx_th_html_text_9.setProperty("contact_info");
    _jspx_th_html_text_9.setSize("36");
    int _jspx_eval_html_text_9 = _jspx_th_html_text_9.doStartTag();
    if (_jspx_th_html_text_9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_9);
    return false;
  }

  private boolean _jspx_meth_logic_present_7(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_7 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_7.setPageContext(pageContext);
    _jspx_th_logic_present_7.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_7.setName("jobBean");
    int _jspx_eval_logic_present_7 = _jspx_th_logic_present_7.doStartTag();
    if (_jspx_eval_logic_present_7 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_10(_jspx_th_logic_present_7, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_7.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_7);
    return false;
  }

  private boolean _jspx_meth_html_text_10(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_7, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_10 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_10.setPageContext(pageContext);
    _jspx_th_html_text_10.setParent(_jspx_th_logic_present_7);
    _jspx_th_html_text_10.setProperty("posting_password");
    _jspx_th_html_text_10.setName("jobBean");
    _jspx_th_html_text_10.setSize("36");
    int _jspx_eval_html_text_10 = _jspx_th_html_text_10.doStartTag();
    if (_jspx_th_html_text_10.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_10);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_6(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_6 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_6.setPageContext(pageContext);
    _jspx_th_logic_notPresent_6.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_6.setName("jobBean");
    int _jspx_eval_logic_notPresent_6 = _jspx_th_logic_notPresent_6.doStartTag();
    if (_jspx_eval_logic_notPresent_6 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_11(_jspx_th_logic_notPresent_6, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_6.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_6);
    return false;
  }

  private boolean _jspx_meth_html_text_11(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_6, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_11 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_11.setPageContext(pageContext);
    _jspx_th_html_text_11.setParent(_jspx_th_logic_notPresent_6);
    _jspx_th_html_text_11.setProperty("posting_password");
    _jspx_th_html_text_11.setSize("36");
    int _jspx_eval_html_text_11 = _jspx_th_html_text_11.doStartTag();
    if (_jspx_th_html_text_11.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_11);
    return false;
  }

  private boolean _jspx_meth_logic_present_8(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_8 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_8.setPageContext(pageContext);
    _jspx_th_logic_present_8.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_8.setName("jobBean");
    int _jspx_eval_logic_present_8 = _jspx_th_logic_present_8.doStartTag();
    if (_jspx_eval_logic_present_8 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_12(_jspx_th_logic_present_8, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_8.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_8);
    return false;
  }

  private boolean _jspx_meth_html_text_12(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_8, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_12 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_name_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_12.setPageContext(pageContext);
    _jspx_th_html_text_12.setParent(_jspx_th_logic_present_8);
    _jspx_th_html_text_12.setProperty("admin_contact_info");
    _jspx_th_html_text_12.setName("jobBean");
    _jspx_th_html_text_12.setSize("36");
    int _jspx_eval_html_text_12 = _jspx_th_html_text_12.doStartTag();
    if (_jspx_th_html_text_12.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_name_nobody.reuse(_jspx_th_html_text_12);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_7(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_7 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_7.setPageContext(pageContext);
    _jspx_th_logic_notPresent_7.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_7.setName("jobBean");
    int _jspx_eval_logic_notPresent_7 = _jspx_th_logic_notPresent_7.doStartTag();
    if (_jspx_eval_logic_notPresent_7 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_text_13(_jspx_th_logic_notPresent_7, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_7.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_7);
    return false;
  }

  private boolean _jspx_meth_html_text_13(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_7, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_13 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_13.setPageContext(pageContext);
    _jspx_th_html_text_13.setParent(_jspx_th_logic_notPresent_7);
    _jspx_th_html_text_13.setProperty("admin_contact_info");
    _jspx_th_html_text_13.setSize("36");
    int _jspx_eval_html_text_13 = _jspx_th_html_text_13.doStartTag();
    if (_jspx_th_html_text_13.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_13);
    return false;
  }

  private boolean _jspx_meth_logic_present_9(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:present ---- */
    org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_9 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
    _jspx_th_logic_present_9.setPageContext(pageContext);
    _jspx_th_logic_present_9.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_present_9.setName("jobBean");
    int _jspx_eval_logic_present_9 = _jspx_th_logic_present_9.doStartTag();
    if (_jspx_eval_logic_present_9 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_textarea_0(_jspx_th_logic_present_9, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_present_9.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_present_9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_9);
    return false;
  }

  private boolean _jspx_meth_html_textarea_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_9, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:textarea ---- */
    org.apache.struts.taglib.html.TextareaTag _jspx_th_html_textarea_0 = (org.apache.struts.taglib.html.TextareaTag) _jspx_tagPool_html_textarea_rows_property_name_cols_nobody.get(org.apache.struts.taglib.html.TextareaTag.class);
    _jspx_th_html_textarea_0.setPageContext(pageContext);
    _jspx_th_html_textarea_0.setParent(_jspx_th_logic_present_9);
    _jspx_th_html_textarea_0.setProperty("job_desc");
    _jspx_th_html_textarea_0.setName("jobBean");
    _jspx_th_html_textarea_0.setRows("15");
    _jspx_th_html_textarea_0.setCols("55");
    int _jspx_eval_html_textarea_0 = _jspx_th_html_textarea_0.doStartTag();
    if (_jspx_th_html_textarea_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_textarea_rows_property_name_cols_nobody.reuse(_jspx_th_html_textarea_0);
    return false;
  }

  private boolean _jspx_meth_logic_notPresent_8(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notPresent ---- */
    org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_8 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
    _jspx_th_logic_notPresent_8.setPageContext(pageContext);
    _jspx_th_logic_notPresent_8.setParent(_jspx_th_html_form_0);
    _jspx_th_logic_notPresent_8.setName("jobBean");
    int _jspx_eval_logic_notPresent_8 = _jspx_th_logic_notPresent_8.doStartTag();
    if (_jspx_eval_logic_notPresent_8 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        if (_jspx_meth_html_textarea_1(_jspx_th_logic_notPresent_8, pageContext))
          return true;
        out.write("\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notPresent_8.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notPresent_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_8);
    return false;
  }

  private boolean _jspx_meth_html_textarea_1(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notPresent_8, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:textarea ---- */
    org.apache.struts.taglib.html.TextareaTag _jspx_th_html_textarea_1 = (org.apache.struts.taglib.html.TextareaTag) _jspx_tagPool_html_textarea_rows_property_cols_nobody.get(org.apache.struts.taglib.html.TextareaTag.class);
    _jspx_th_html_textarea_1.setPageContext(pageContext);
    _jspx_th_html_textarea_1.setParent(_jspx_th_logic_notPresent_8);
    _jspx_th_html_textarea_1.setProperty("job_desc");
    _jspx_th_html_textarea_1.setRows("15");
    _jspx_th_html_textarea_1.setCols("55");
    int _jspx_eval_html_textarea_1 = _jspx_th_html_textarea_1.doStartTag();
    if (_jspx_th_html_textarea_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_textarea_rows_property_cols_nobody.reuse(_jspx_th_html_textarea_1);
    return false;
  }

  private boolean _jspx_meth_html_hidden_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_10, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:hidden ---- */
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_hidden_0 = (org.apache.struts.taglib.html.HiddenTag) _jspx_tagPool_html_hidden_property_name_nobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_hidden_0.setPageContext(pageContext);
    _jspx_th_html_hidden_0.setParent(_jspx_th_logic_present_10);
    _jspx_th_html_hidden_0.setProperty("job_number");
    _jspx_th_html_hidden_0.setName("jobBean");
    int _jspx_eval_html_hidden_0 = _jspx_th_html_hidden_0.doStartTag();
    if (_jspx_th_html_hidden_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_hidden_property_name_nobody.reuse(_jspx_th_html_hidden_0);
    return false;
  }

  private boolean _jspx_meth_html_reset_0(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:reset ---- */
    org.apache.struts.taglib.html.ResetTag _jspx_th_html_reset_0 = (org.apache.struts.taglib.html.ResetTag) _jspx_tagPool_html_reset_value_nobody.get(org.apache.struts.taglib.html.ResetTag.class);
    _jspx_th_html_reset_0.setPageContext(pageContext);
    _jspx_th_html_reset_0.setParent(_jspx_th_html_form_0);
    _jspx_th_html_reset_0.setValue("RESET FIELDS");
    int _jspx_eval_html_reset_0 = _jspx_th_html_reset_0.doStartTag();
    if (_jspx_th_html_reset_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_reset_value_nobody.reuse(_jspx_th_html_reset_0);
    return false;
  }
}

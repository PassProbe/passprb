package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import org.jugjobs.form.PostingFormBean;
import org.jugjobs.controller.Constants;

public class jobsTable_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_equal_value_scope_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_form_action;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_submit_value_property_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_notEqual_value_scope_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_iterate_property_name_id;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_notEmpty_property_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_bean_write_property_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_empty_property_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_hidden_property_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_text_size_property_nobody;

  public jobsTable_jsp() {
    _jspx_tagPool_logic_equal_value_scope_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_form_action = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_submit_value_property_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_notEqual_value_scope_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_iterate_property_name_id = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_notEmpty_property_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_bean_write_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_empty_property_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_hidden_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_text_size_property_nobody = new org.apache.jasper.runtime.TagHandlerPool();
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspDestroy() {
    _jspx_tagPool_logic_equal_value_scope_name.release();
    _jspx_tagPool_html_form_action.release();
    _jspx_tagPool_html_submit_value_property_nobody.release();
    _jspx_tagPool_logic_notEqual_value_scope_name.release();
    _jspx_tagPool_logic_iterate_property_name_id.release();
    _jspx_tagPool_logic_notEmpty_property_name.release();
    _jspx_tagPool_bean_write_property_name_nobody.release();
    _jspx_tagPool_logic_empty_property_name.release();
    _jspx_tagPool_html_hidden_property_name_nobody.release();
    _jspx_tagPool_html_text_size_property_nobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n/* \r\n * JUGJobs - A Jobs Posting Application for Java Users Groups and Other Groups\r\n * $Id: $\r\n * \r\n * ***** BEGIN LICENSE BLOCK *****\r\n * Version: MPL 1.1\r\n *\r\n * The contents of this file are subject to the Mozilla Public License Version\r\n * 1.1 (the \"License\"); you may not use this file except in compliance with\r\n * the License. You may obtain a copy of the License at\r\n * http://www.mozilla.org/MPL/\r\n *\r\n * Software distributed under the License is distributed on an \"AS IS\" basis,\r\n * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License\r\n * for the specific language governing rights and limitations under the\r\n * License.\r\n *\r\n * The Original Code is the JUGJobs project.\r\n *\r\n * The Initial Developers of the Original Code are the members of the Triangle\r\n * Java User's Group in the RTP area of North Carolina.\r\n * Portions created by the Initial Developer are Copyright (C) 2005\r\n * the Initial Developers. All Rights Reserved.\r\n *\r\n * Contributor(s):\r\n *\r\n * ***** END LICENSE BLOCK ***** \r\n");
      out.write(" */\r\n -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\ntable is here!!\r\n\r\n");
      out.write("<table border=\"0\" cellpadding=\"5\" cellspacing=\"0\" width=\"100%\">\r\n");
      out.write("<tr>\r\n  ");
      out.write("<td valign=\"top\">\r\n    ");
      /* ----  logic:equal ---- */
      org.apache.struts.taglib.logic.EqualTag _jspx_th_logic_equal_0 = (org.apache.struts.taglib.logic.EqualTag) _jspx_tagPool_logic_equal_value_scope_name.get(org.apache.struts.taglib.logic.EqualTag.class);
      _jspx_th_logic_equal_0.setPageContext(pageContext);
      _jspx_th_logic_equal_0.setParent(null);
      _jspx_th_logic_equal_0.setName("ADMIN_LOGGED_IN");
      _jspx_th_logic_equal_0.setScope("session");
      _jspx_th_logic_equal_0.setValue("ADMIN_LOGGED_IN");
      int _jspx_eval_logic_equal_0 = _jspx_th_logic_equal_0.doStartTag();
      if (_jspx_eval_logic_equal_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n      ");
          /* ----  html:form ---- */
          org.apache.struts.taglib.html.FormTag _jspx_th_html_form_0 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_action.get(org.apache.struts.taglib.html.FormTag.class);
          _jspx_th_html_form_0.setPageContext(pageContext);
          _jspx_th_html_form_0.setParent(_jspx_th_logic_equal_0);
          _jspx_th_html_form_0.setAction("adminEdit.do");
          int _jspx_eval_html_form_0 = _jspx_th_html_form_0.doStartTag();
          if (_jspx_eval_html_form_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n        ");
              out.write("<h2 align=\"center\">Administrator's View of Jobs List");
              out.write("</h2>\r\n        ");
              out.write("<center>\r\n          ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_0 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_0.setPageContext(pageContext);
              _jspx_th_html_submit_0.setParent(_jspx_th_html_form_0);
              _jspx_th_html_submit_0.setValue( Constants.ADMIN_LOGOUT_BUTTON_VALUE);
              _jspx_th_html_submit_0.setProperty("button");
              int _jspx_eval_html_submit_0 = _jspx_th_html_submit_0.doStartTag();
              if (_jspx_th_html_submit_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_0);
              out.write("\r\n        ");
              out.write("</center>\r\n      ");
              int evalDoAfterBody = _jspx_th_html_form_0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_html_form_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_html_form_action.reuse(_jspx_th_html_form_0);
          out.write("\r\n    ");
          int evalDoAfterBody = _jspx_th_logic_equal_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_logic_equal_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_logic_equal_value_scope_name.reuse(_jspx_th_logic_equal_0);
      out.write("\r\n    ");
      /* ----  logic:notEqual ---- */
      org.apache.struts.taglib.logic.NotEqualTag _jspx_th_logic_notEqual_0 = (org.apache.struts.taglib.logic.NotEqualTag) _jspx_tagPool_logic_notEqual_value_scope_name.get(org.apache.struts.taglib.logic.NotEqualTag.class);
      _jspx_th_logic_notEqual_0.setPageContext(pageContext);
      _jspx_th_logic_notEqual_0.setParent(null);
      _jspx_th_logic_notEqual_0.setName("ADMIN_LOGGED_IN");
      _jspx_th_logic_notEqual_0.setScope("session");
      _jspx_th_logic_notEqual_0.setValue("ADMIN_LOGGED_IN");
      int _jspx_eval_logic_notEqual_0 = _jspx_th_logic_notEqual_0.doStartTag();
      if (_jspx_eval_logic_notEqual_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n      ");
          /* ----  html:form ---- */
          org.apache.struts.taglib.html.FormTag _jspx_th_html_form_1 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_action.get(org.apache.struts.taglib.html.FormTag.class);
          _jspx_th_html_form_1.setPageContext(pageContext);
          _jspx_th_html_form_1.setParent(_jspx_th_logic_notEqual_0);
          _jspx_th_html_form_1.setAction("getEdit.do");
          int _jspx_eval_html_form_1 = _jspx_th_html_form_1.doStartTag();
          if (_jspx_eval_html_form_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n        ");
              out.write("<p class=\"header4\" align=\"center\">Jobs:");
              out.write("</p>\r\n        ");
              out.write("<p>");
              out.write("<span class=\"header2\">Details:");
              out.write("</span>");
              out.write("<br>\r\n          If you would like to add a job to the list below, \r\n          please familiarize yourself with our \r\n          ");
              out.write("<a href=\"jobspolicy.jsp\">listing policy");
              out.write("</a>, then\r\n            ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_1 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_1.setPageContext(pageContext);
              _jspx_th_html_submit_1.setParent(_jspx_th_html_form_1);
              _jspx_th_html_submit_1.setValue( Constants.ADD_BUTTON_VALUE);
              _jspx_th_html_submit_1.setProperty("button");
              int _jspx_eval_html_submit_1 = _jspx_th_html_submit_1.doStartTag();
              if (_jspx_th_html_submit_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_1);
              out.write(".\r\n        ");
              out.write("</p>\r\n        ");
              out.write("<ol type=\"disc\">\r\n          ");
              out.write("<li>These listings normally remain at least 60 days.");
              out.write("</li>\r\n          ");
              out.write("<li>If you want to either edit or remove your job listing,\r\n             enter your password at the end of the listing.");
              out.write("</li>\r\n          ");
              out.write("<li>If you have questions or problems, \r\n            ");
              JspRuntimeLibrary.include(request, response, "includes/webmaster.jsp", out, true);
              out.write(".\r\n          ");
              out.write("</li>\r\n        ");
              out.write("</ol>\r\n      ");
              int evalDoAfterBody = _jspx_th_html_form_1.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_html_form_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_html_form_action.reuse(_jspx_th_html_form_1);
          out.write("\r\n    ");
          int evalDoAfterBody = _jspx_th_logic_notEqual_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_logic_notEqual_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_logic_notEqual_value_scope_name.reuse(_jspx_th_logic_notEqual_0);
      out.write("\r\n    ");
      out.write("<br>\r\n    ");
      org.jugjobs.model.PostingsList modelBean = null;
      synchronized (application) {
        modelBean = (org.jugjobs.model.PostingsList) pageContext.getAttribute("modelBean", PageContext.APPLICATION_SCOPE);
        if (modelBean == null){
          try {
            modelBean = (org.jugjobs.model.PostingsList) java.beans.Beans.instantiate(this.getClass().getClassLoader(), "org.jugjobs.model.PostingsList");
          } catch (ClassNotFoundException exc) {
            throw new InstantiationException(exc.getMessage());
          } catch (Exception exc) {
            throw new ServletException("Cannot create bean of class " + "org.jugjobs.model.PostingsList", exc);
          }
          pageContext.setAttribute("modelBean", modelBean, PageContext.APPLICATION_SCOPE);
        }
      }
      out.write("\r\n    \r\n    ");
      out.write("<table border=\"0\" width=\"100%\" cellpadding=\"5\" cellspacing=\"0\" \r\n                                          bordercolor=\"#247B7B\">\r\n    ");
      /* ----  logic:iterate ---- */
      org.apache.struts.taglib.logic.IterateTag _jspx_th_logic_iterate_0 = (org.apache.struts.taglib.logic.IterateTag) _jspx_tagPool_logic_iterate_property_name_id.get(org.apache.struts.taglib.logic.IterateTag.class);
      _jspx_th_logic_iterate_0.setPageContext(pageContext);
      _jspx_th_logic_iterate_0.setParent(null);
      _jspx_th_logic_iterate_0.setName("modelBean");
      _jspx_th_logic_iterate_0.setProperty("postingsList");
      _jspx_th_logic_iterate_0.setId("jobN");
      int _jspx_eval_logic_iterate_0 = _jspx_th_logic_iterate_0.doStartTag();
      if (_jspx_eval_logic_iterate_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        java.lang.Object jobN = null;
        if (_jspx_eval_logic_iterate_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
          javax.servlet.jsp.tagext.BodyContent _bc = pageContext.pushBody();
          out = _bc;
          _jspx_th_logic_iterate_0.setBodyContent(_bc);
          _jspx_th_logic_iterate_0.doInitBody();
        }
        jobN = (java.lang.Object) pageContext.findAttribute("jobN");
        do {
          out.write("\r\n    ");
          if (_jspx_meth_logic_notEmpty_0(_jspx_th_logic_iterate_0, pageContext))
            return;
          out.write("\r\n    ");
          /* ----  logic:empty ---- */
          org.apache.struts.taglib.logic.EmptyTag _jspx_th_logic_empty_0 = (org.apache.struts.taglib.logic.EmptyTag) _jspx_tagPool_logic_empty_property_name.get(org.apache.struts.taglib.logic.EmptyTag.class);
          _jspx_th_logic_empty_0.setPageContext(pageContext);
          _jspx_th_logic_empty_0.setParent(_jspx_th_logic_iterate_0);
          _jspx_th_logic_empty_0.setName("jobN");
          _jspx_th_logic_empty_0.setProperty("errorMessage");
          int _jspx_eval_logic_empty_0 = _jspx_th_logic_empty_0.doStartTag();
          if (_jspx_eval_logic_empty_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n      ");
              out.write("<tr>\r\n        ");
              out.write("<th align=left width=445 class=dbitem>\r\n          ");
              if (_jspx_meth_logic_notEmpty_1(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("<FONT COLOR=BLUE>\r\n              ");
              if (_jspx_meth_bean_write_3(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("</FONT>\r\n          ");
              if (_jspx_meth_logic_notEmpty_2(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n        ");
              out.write("</th>\r\n      ");
              out.write("</tr>\r\n      ");
              out.write("<tr>\r\n        ");
              out.write("<td>\r\n          ");
              out.write("<table border=1 width=\"100%\"  cellpadding=\"5\" cellspacing=\"0\" \r\n                                      bordercolor=\"#247B7B\">\r\n          ");
              out.write("<tr> ");
              out.write("\r\n            ");
              out.write("<td width=610 colspan=\"2\">\r\n              ");
              out.write("<b>Job Title: ");
              out.write("</b> ");
              if (_jspx_meth_bean_write_4(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("</td>\r\n          ");
              out.write("</tr>\r\n          ");
              out.write("<tr> ");
              out.write("\r\n            ");
              out.write("<td width=610 colspan=\"2\">\r\n              ");
              out.write("<b>Job Description:");
              out.write("</b>");
              out.write("<br>\r\n              ");
              if (_jspx_meth_bean_write_5(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("</td>\r\n          ");
              out.write("</tr>\r\n          ");
              out.write("<tr>\r\n            ");
              out.write("<td width=\"40%\"> ");
              out.write("\r\n              ");
              out.write("<b>Contact Person:");
              out.write("</b>");
              out.write("<br>\r\n              ");
              if (_jspx_meth_bean_write_6(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("</td>\r\n            ");
              out.write("<td width=\"60%\"> ");
              out.write("\r\n              ");
              out.write("<b>Contact Information:");
              out.write("</b>");
              out.write("<br>\r\n              ");
              if (_jspx_meth_bean_write_7(_jspx_th_logic_empty_0, pageContext))
                return;
              out.write("\r\n            ");
              out.write("</td>\r\n          ");
              out.write("</tr>\r\n          ");
              out.write("<tr>\r\n            ");
              out.write("<td width=\"40%\"> \r\n              ");
              /* ----  logic:equal ---- */
              org.apache.struts.taglib.logic.EqualTag _jspx_th_logic_equal_1 = (org.apache.struts.taglib.logic.EqualTag) _jspx_tagPool_logic_equal_value_scope_name.get(org.apache.struts.taglib.logic.EqualTag.class);
              _jspx_th_logic_equal_1.setPageContext(pageContext);
              _jspx_th_logic_equal_1.setParent(_jspx_th_logic_empty_0);
              _jspx_th_logic_equal_1.setName("ADMIN_LOGGED_IN");
              _jspx_th_logic_equal_1.setScope("session");
              _jspx_th_logic_equal_1.setValue( Constants.ADMIN_LOGGED_IN);
              int _jspx_eval_logic_equal_1 = _jspx_th_logic_equal_1.doStartTag();
              if (_jspx_eval_logic_equal_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                do {
                  out.write("\r\n                ");
                  out.write("<b>Contact Information for Administrator:");
                  out.write("</b>");
                  out.write("<br>\r\n                ");
                  if (_jspx_meth_bean_write_8(_jspx_th_logic_equal_1, pageContext))
                    return;
                  out.write("\r\n              ");
                  int evalDoAfterBody = _jspx_th_logic_equal_1.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_logic_equal_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_logic_equal_value_scope_name.reuse(_jspx_th_logic_equal_1);
              out.write("\r\n              ");
              /* ----  logic:notEqual ---- */
              org.apache.struts.taglib.logic.NotEqualTag _jspx_th_logic_notEqual_1 = (org.apache.struts.taglib.logic.NotEqualTag) _jspx_tagPool_logic_notEqual_value_scope_name.get(org.apache.struts.taglib.logic.NotEqualTag.class);
              _jspx_th_logic_notEqual_1.setPageContext(pageContext);
              _jspx_th_logic_notEqual_1.setParent(_jspx_th_logic_empty_0);
              _jspx_th_logic_notEqual_1.setName("ADMIN_LOGGED_IN");
              _jspx_th_logic_notEqual_1.setScope("session");
              _jspx_th_logic_notEqual_1.setValue( Constants.ADMIN_LOGGED_IN);
              int _jspx_eval_logic_notEqual_1 = _jspx_th_logic_notEqual_1.doStartTag();
              if (_jspx_eval_logic_notEqual_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                do {
                  out.write("\r\n                ");
                  out.write("<b>Last Updated:");
                  out.write("</b>");
                  out.write("<br>\r\n                ");
                  if (_jspx_meth_bean_write_9(_jspx_th_logic_notEqual_1, pageContext))
                    return;
                  out.write("\r\n              ");
                  int evalDoAfterBody = _jspx_th_logic_notEqual_1.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_logic_notEqual_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_logic_notEqual_value_scope_name.reuse(_jspx_th_logic_notEqual_1);
              out.write("\r\n            ");
              out.write("</td>\r\n            ");
              out.write("<td width=\"60%\"> \r\n              ");
              /* ----  logic:equal ---- */
              org.apache.struts.taglib.logic.EqualTag _jspx_th_logic_equal_2 = (org.apache.struts.taglib.logic.EqualTag) _jspx_tagPool_logic_equal_value_scope_name.get(org.apache.struts.taglib.logic.EqualTag.class);
              _jspx_th_logic_equal_2.setPageContext(pageContext);
              _jspx_th_logic_equal_2.setParent(_jspx_th_logic_empty_0);
              _jspx_th_logic_equal_2.setName("ADMIN_LOGGED_IN");
              _jspx_th_logic_equal_2.setScope("session");
              _jspx_th_logic_equal_2.setValue( Constants.ADMIN_LOGGED_IN);
              int _jspx_eval_logic_equal_2 = _jspx_th_logic_equal_2.doStartTag();
              if (_jspx_eval_logic_equal_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                do {
                  out.write("\r\n                ");
                  /* ----  html:form ---- */
                  org.apache.struts.taglib.html.FormTag _jspx_th_html_form_2 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_action.get(org.apache.struts.taglib.html.FormTag.class);
                  _jspx_th_html_form_2.setPageContext(pageContext);
                  _jspx_th_html_form_2.setParent(_jspx_th_logic_equal_2);
                  _jspx_th_html_form_2.setAction("adminEdit.do");
                  int _jspx_eval_html_form_2 = _jspx_th_html_form_2.doStartTag();
                  if (_jspx_eval_html_form_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                    do {
                      out.write("\r\n                  Last Updated:\r\n                  ");
                      if (_jspx_meth_bean_write_10(_jspx_th_html_form_2, pageContext))
                        return;
                      out.write("&nbsp;\r\n                  ");
                      if (_jspx_meth_html_hidden_0(_jspx_th_html_form_2, pageContext))
                        return;
                      out.write("\r\n                  ");
                      /* ----  html:submit ---- */
                      org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_2 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
                      _jspx_th_html_submit_2.setPageContext(pageContext);
                      _jspx_th_html_submit_2.setParent(_jspx_th_html_form_2);
                      _jspx_th_html_submit_2.setValue( Constants.ADMIN_EDIT_BUTTON_VALUE);
                      _jspx_th_html_submit_2.setProperty("button");
                      int _jspx_eval_html_submit_2 = _jspx_th_html_submit_2.doStartTag();
                      if (_jspx_th_html_submit_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                        return;
                      _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_2);
                      out.write("\r\n                ");
                      int evalDoAfterBody = _jspx_th_html_form_2.doAfterBody();
                      if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                        break;
                    } while (true);
                  }
                  if (_jspx_th_html_form_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                    return;
                  _jspx_tagPool_html_form_action.reuse(_jspx_th_html_form_2);
                  out.write("\r\n              ");
                  int evalDoAfterBody = _jspx_th_logic_equal_2.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_logic_equal_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_logic_equal_value_scope_name.reuse(_jspx_th_logic_equal_2);
              out.write("\r\n              ");
              /* ----  logic:notEqual ---- */
              org.apache.struts.taglib.logic.NotEqualTag _jspx_th_logic_notEqual_2 = (org.apache.struts.taglib.logic.NotEqualTag) _jspx_tagPool_logic_notEqual_value_scope_name.get(org.apache.struts.taglib.logic.NotEqualTag.class);
              _jspx_th_logic_notEqual_2.setPageContext(pageContext);
              _jspx_th_logic_notEqual_2.setParent(_jspx_th_logic_empty_0);
              _jspx_th_logic_notEqual_2.setName("ADMIN_LOGGED_IN");
              _jspx_th_logic_notEqual_2.setScope("session");
              _jspx_th_logic_notEqual_2.setValue( Constants.ADMIN_LOGGED_IN);
              int _jspx_eval_logic_notEqual_2 = _jspx_th_logic_notEqual_2.doStartTag();
              if (_jspx_eval_logic_notEqual_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                do {
                  out.write("\r\n                ");
                  /* ----  html:form ---- */
                  org.apache.struts.taglib.html.FormTag _jspx_th_html_form_3 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_action.get(org.apache.struts.taglib.html.FormTag.class);
                  _jspx_th_html_form_3.setPageContext(pageContext);
                  _jspx_th_html_form_3.setParent(_jspx_th_logic_notEqual_2);
                  _jspx_th_html_form_3.setAction("getEdit.do");
                  int _jspx_eval_html_form_3 = _jspx_th_html_form_3.doStartTag();
                  if (_jspx_eval_html_form_3 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
                    do {
                      out.write("\r\n                  ");
                      out.write("<b>Password:");
                      out.write("</b>&nbsp;\r\n                  ");
                      if (_jspx_meth_html_text_0(_jspx_th_html_form_3, pageContext))
                        return;
                      out.write("&nbsp;\r\n                  ");
                      if (_jspx_meth_html_hidden_1(_jspx_th_html_form_3, pageContext))
                        return;
                      out.write("\r\n                  ");
                      /* ----  html:submit ---- */
                      org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_3 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
                      _jspx_th_html_submit_3.setPageContext(pageContext);
                      _jspx_th_html_submit_3.setParent(_jspx_th_html_form_3);
                      _jspx_th_html_submit_3.setValue( Constants.USER_EDIT_BUTTON_VALUE);
                      _jspx_th_html_submit_3.setProperty("button");
                      int _jspx_eval_html_submit_3 = _jspx_th_html_submit_3.doStartTag();
                      if (_jspx_th_html_submit_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                        return;
                      _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_3);
                      out.write("\r\n                ");
                      int evalDoAfterBody = _jspx_th_html_form_3.doAfterBody();
                      if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                        break;
                    } while (true);
                  }
                  if (_jspx_th_html_form_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                    return;
                  _jspx_tagPool_html_form_action.reuse(_jspx_th_html_form_3);
                  out.write("\r\n              ");
                  int evalDoAfterBody = _jspx_th_logic_notEqual_2.doAfterBody();
                  if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                    break;
                } while (true);
              }
              if (_jspx_th_logic_notEqual_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_logic_notEqual_value_scope_name.reuse(_jspx_th_logic_notEqual_2);
              out.write("\r\n            ");
              out.write("</td>\r\n           ");
              out.write("</tr>\r\n          ");
              out.write("</table>");
              out.write("<br>\r\n          ");
              out.write("<p>&nbsp;");
              out.write("</p>\r\n        ");
              out.write("</td>\r\n        ");
              out.write("</tr>\r\n      ");
              int evalDoAfterBody = _jspx_th_logic_empty_0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_empty_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_empty_property_name.reuse(_jspx_th_logic_empty_0);
          out.write("\r\n    ");
          int evalDoAfterBody = _jspx_th_logic_iterate_0.doAfterBody();
          jobN = (java.lang.Object) pageContext.findAttribute("jobN");
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
        if (_jspx_eval_logic_iterate_0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE)
          out = pageContext.popBody();
      }
      if (_jspx_th_logic_iterate_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_logic_iterate_property_name_id.reuse(_jspx_th_logic_iterate_0);
      out.write("\r\n    ");
      out.write("</table>\r\n  ");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
      out.write("</table>\r\n\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }

  private boolean _jspx_meth_logic_notEmpty_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_iterate_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notEmpty ---- */
    org.apache.struts.taglib.logic.NotEmptyTag _jspx_th_logic_notEmpty_0 = (org.apache.struts.taglib.logic.NotEmptyTag) _jspx_tagPool_logic_notEmpty_property_name.get(org.apache.struts.taglib.logic.NotEmptyTag.class);
    _jspx_th_logic_notEmpty_0.setPageContext(pageContext);
    _jspx_th_logic_notEmpty_0.setParent(_jspx_th_logic_iterate_0);
    _jspx_th_logic_notEmpty_0.setName("jobN");
    _jspx_th_logic_notEmpty_0.setProperty("errorMessage");
    int _jspx_eval_logic_notEmpty_0 = _jspx_th_logic_notEmpty_0.doStartTag();
    if (_jspx_eval_logic_notEmpty_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n      ");
        out.write("<tr>\r\n        ");
        out.write("<td>\r\n          Sadly, an error has occurred that prevents the reading of the jobs list at this time.");
        out.write("<br />\r\n          ");
        if (_jspx_meth_bean_write_0(_jspx_th_logic_notEmpty_0, pageContext))
          return true;
        out.write("<br />\r\n          ");
        if (_jspx_meth_bean_write_1(_jspx_th_logic_notEmpty_0, pageContext))
          return true;
        out.write("\r\n        ");
        out.write("</td>\r\n      ");
        out.write("</tr>\r\n    ");
        int evalDoAfterBody = _jspx_th_logic_notEmpty_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notEmpty_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notEmpty_property_name.reuse(_jspx_th_logic_notEmpty_0);
    return false;
  }

  private boolean _jspx_meth_bean_write_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notEmpty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_0 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_0.setPageContext(pageContext);
    _jspx_th_bean_write_0.setParent(_jspx_th_logic_notEmpty_0);
    _jspx_th_bean_write_0.setName("jobN");
    _jspx_th_bean_write_0.setProperty("errorMessage");
    int _jspx_eval_bean_write_0 = _jspx_th_bean_write_0.doStartTag();
    if (_jspx_th_bean_write_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_0);
    return false;
  }

  private boolean _jspx_meth_bean_write_1(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notEmpty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_1 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_1.setPageContext(pageContext);
    _jspx_th_bean_write_1.setParent(_jspx_th_logic_notEmpty_0);
    _jspx_th_bean_write_1.setName("jobN");
    _jspx_th_bean_write_1.setProperty("errorInfo");
    int _jspx_eval_bean_write_1 = _jspx_th_bean_write_1.doStartTag();
    if (_jspx_th_bean_write_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_1);
    return false;
  }

  private boolean _jspx_meth_logic_notEmpty_1(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notEmpty ---- */
    org.apache.struts.taglib.logic.NotEmptyTag _jspx_th_logic_notEmpty_1 = (org.apache.struts.taglib.logic.NotEmptyTag) _jspx_tagPool_logic_notEmpty_property_name.get(org.apache.struts.taglib.logic.NotEmptyTag.class);
    _jspx_th_logic_notEmpty_1.setPageContext(pageContext);
    _jspx_th_logic_notEmpty_1.setParent(_jspx_th_logic_empty_0);
    _jspx_th_logic_notEmpty_1.setName("jobN");
    _jspx_th_logic_notEmpty_1.setProperty("employer_url");
    int _jspx_eval_logic_notEmpty_1 = _jspx_th_logic_notEmpty_1.doStartTag();
    if (_jspx_eval_logic_notEmpty_1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        out.write("<a href=\"http://");
        if (_jspx_meth_bean_write_2(_jspx_th_logic_notEmpty_1, pageContext))
          return true;
        out.write("\">\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notEmpty_1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notEmpty_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notEmpty_property_name.reuse(_jspx_th_logic_notEmpty_1);
    return false;
  }

  private boolean _jspx_meth_bean_write_2(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notEmpty_1, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_2 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_2.setPageContext(pageContext);
    _jspx_th_bean_write_2.setParent(_jspx_th_logic_notEmpty_1);
    _jspx_th_bean_write_2.setName("jobN");
    _jspx_th_bean_write_2.setProperty("employer_url");
    int _jspx_eval_bean_write_2 = _jspx_th_bean_write_2.doStartTag();
    if (_jspx_th_bean_write_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_2);
    return false;
  }

  private boolean _jspx_meth_bean_write_3(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_3 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_3.setPageContext(pageContext);
    _jspx_th_bean_write_3.setParent(_jspx_th_logic_empty_0);
    _jspx_th_bean_write_3.setName("jobN");
    _jspx_th_bean_write_3.setProperty("employer_name");
    int _jspx_eval_bean_write_3 = _jspx_th_bean_write_3.doStartTag();
    if (_jspx_th_bean_write_3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_3);
    return false;
  }

  private boolean _jspx_meth_logic_notEmpty_2(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  logic:notEmpty ---- */
    org.apache.struts.taglib.logic.NotEmptyTag _jspx_th_logic_notEmpty_2 = (org.apache.struts.taglib.logic.NotEmptyTag) _jspx_tagPool_logic_notEmpty_property_name.get(org.apache.struts.taglib.logic.NotEmptyTag.class);
    _jspx_th_logic_notEmpty_2.setPageContext(pageContext);
    _jspx_th_logic_notEmpty_2.setParent(_jspx_th_logic_empty_0);
    _jspx_th_logic_notEmpty_2.setName("jobN");
    _jspx_th_logic_notEmpty_2.setProperty("employer_url");
    int _jspx_eval_logic_notEmpty_2 = _jspx_th_logic_notEmpty_2.doStartTag();
    if (_jspx_eval_logic_notEmpty_2 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n            ");
        out.write("</a>\r\n          ");
        int evalDoAfterBody = _jspx_th_logic_notEmpty_2.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_notEmpty_2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_notEmpty_property_name.reuse(_jspx_th_logic_notEmpty_2);
    return false;
  }

  private boolean _jspx_meth_bean_write_4(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_4 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_4.setPageContext(pageContext);
    _jspx_th_bean_write_4.setParent(_jspx_th_logic_empty_0);
    _jspx_th_bean_write_4.setName("jobN");
    _jspx_th_bean_write_4.setProperty("job_title");
    int _jspx_eval_bean_write_4 = _jspx_th_bean_write_4.doStartTag();
    if (_jspx_th_bean_write_4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_4);
    return false;
  }

  private boolean _jspx_meth_bean_write_5(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_5 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_5.setPageContext(pageContext);
    _jspx_th_bean_write_5.setParent(_jspx_th_logic_empty_0);
    _jspx_th_bean_write_5.setName("jobN");
    _jspx_th_bean_write_5.setProperty("job_desc");
    int _jspx_eval_bean_write_5 = _jspx_th_bean_write_5.doStartTag();
    if (_jspx_th_bean_write_5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_5);
    return false;
  }

  private boolean _jspx_meth_bean_write_6(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_6 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_6.setPageContext(pageContext);
    _jspx_th_bean_write_6.setParent(_jspx_th_logic_empty_0);
    _jspx_th_bean_write_6.setName("jobN");
    _jspx_th_bean_write_6.setProperty("contact_name");
    int _jspx_eval_bean_write_6 = _jspx_th_bean_write_6.doStartTag();
    if (_jspx_th_bean_write_6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_6);
    return false;
  }

  private boolean _jspx_meth_bean_write_7(javax.servlet.jsp.tagext.Tag _jspx_th_logic_empty_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_7 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_7.setPageContext(pageContext);
    _jspx_th_bean_write_7.setParent(_jspx_th_logic_empty_0);
    _jspx_th_bean_write_7.setName("jobN");
    _jspx_th_bean_write_7.setProperty("contact_info");
    int _jspx_eval_bean_write_7 = _jspx_th_bean_write_7.doStartTag();
    if (_jspx_th_bean_write_7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_7);
    return false;
  }

  private boolean _jspx_meth_bean_write_8(javax.servlet.jsp.tagext.Tag _jspx_th_logic_equal_1, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_8 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_8.setPageContext(pageContext);
    _jspx_th_bean_write_8.setParent(_jspx_th_logic_equal_1);
    _jspx_th_bean_write_8.setName("jobN");
    _jspx_th_bean_write_8.setProperty("admin_contact_info");
    int _jspx_eval_bean_write_8 = _jspx_th_bean_write_8.doStartTag();
    if (_jspx_th_bean_write_8.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_8);
    return false;
  }

  private boolean _jspx_meth_bean_write_9(javax.servlet.jsp.tagext.Tag _jspx_th_logic_notEqual_1, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_9 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_9.setPageContext(pageContext);
    _jspx_th_bean_write_9.setParent(_jspx_th_logic_notEqual_1);
    _jspx_th_bean_write_9.setName("jobN");
    _jspx_th_bean_write_9.setProperty("last_edit_date");
    int _jspx_eval_bean_write_9 = _jspx_th_bean_write_9.doStartTag();
    if (_jspx_th_bean_write_9.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_9);
    return false;
  }

  private boolean _jspx_meth_bean_write_10(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_2, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_10 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_10.setPageContext(pageContext);
    _jspx_th_bean_write_10.setParent(_jspx_th_html_form_2);
    _jspx_th_bean_write_10.setName("jobN");
    _jspx_th_bean_write_10.setProperty("last_edit_date");
    int _jspx_eval_bean_write_10 = _jspx_th_bean_write_10.doStartTag();
    if (_jspx_th_bean_write_10.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_10);
    return false;
  }

  private boolean _jspx_meth_html_hidden_0(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_2, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:hidden ---- */
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_hidden_0 = (org.apache.struts.taglib.html.HiddenTag) _jspx_tagPool_html_hidden_property_name_nobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_hidden_0.setPageContext(pageContext);
    _jspx_th_html_hidden_0.setParent(_jspx_th_html_form_2);
    _jspx_th_html_hidden_0.setProperty("job_number");
    _jspx_th_html_hidden_0.setName("jobN");
    int _jspx_eval_html_hidden_0 = _jspx_th_html_hidden_0.doStartTag();
    if (_jspx_th_html_hidden_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_hidden_property_name_nobody.reuse(_jspx_th_html_hidden_0);
    return false;
  }

  private boolean _jspx_meth_html_text_0(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_3, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:text ---- */
    org.apache.struts.taglib.html.TextTag _jspx_th_html_text_0 = (org.apache.struts.taglib.html.TextTag) _jspx_tagPool_html_text_size_property_nobody.get(org.apache.struts.taglib.html.TextTag.class);
    _jspx_th_html_text_0.setPageContext(pageContext);
    _jspx_th_html_text_0.setParent(_jspx_th_html_form_3);
    _jspx_th_html_text_0.setProperty("posting_password");
    _jspx_th_html_text_0.setSize("9");
    int _jspx_eval_html_text_0 = _jspx_th_html_text_0.doStartTag();
    if (_jspx_th_html_text_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_text_size_property_nobody.reuse(_jspx_th_html_text_0);
    return false;
  }

  private boolean _jspx_meth_html_hidden_1(javax.servlet.jsp.tagext.Tag _jspx_th_html_form_3, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:hidden ---- */
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_hidden_1 = (org.apache.struts.taglib.html.HiddenTag) _jspx_tagPool_html_hidden_property_name_nobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_hidden_1.setPageContext(pageContext);
    _jspx_th_html_hidden_1.setParent(_jspx_th_html_form_3);
    _jspx_th_html_hidden_1.setProperty("job_number");
    _jspx_th_html_hidden_1.setName("jobN");
    int _jspx_eval_html_hidden_1 = _jspx_th_html_hidden_1.doStartTag();
    if (_jspx_th_html_hidden_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_hidden_property_name_nobody.reuse(_jspx_th_html_hidden_1);
    return false;
  }
}

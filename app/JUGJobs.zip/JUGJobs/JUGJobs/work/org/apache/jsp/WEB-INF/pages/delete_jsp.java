package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;
import org.jugjobs.controller.Constants;
import org.jugjobs.controller.JobsServlet;

public class delete_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_form_action;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_notPresent_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_present_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_bean_write_property_name_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_submit_value_property_nobody;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_hidden_property_name_nobody;

  public delete_jsp() {
    _jspx_tagPool_html_form_action = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_notPresent_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_present_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_bean_write_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_submit_value_property_nobody = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_html_hidden_property_name_nobody = new org.apache.jasper.runtime.TagHandlerPool();
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspDestroy() {
    _jspx_tagPool_html_form_action.release();
    _jspx_tagPool_logic_notPresent_name.release();
    _jspx_tagPool_logic_present_name.release();
    _jspx_tagPool_bean_write_property_name_nobody.release();
    _jspx_tagPool_html_submit_value_property_nobody.release();
    _jspx_tagPool_html_hidden_property_name_nobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n/* \r\n * JUGJobs - A Jobs Posting Application for Java Users Groups and Other Groups\r\n * $Id: $\r\n * \r\n * ***** BEGIN LICENSE BLOCK *****\r\n * Version: MPL 1.1\r\n *\r\n * The contents of this file are subject to the Mozilla Public License Version\r\n * 1.1 (the \"License\"); you may not use this file except in compliance with\r\n * the License. You may obtain a copy of the License at\r\n * http://www.mozilla.org/MPL/\r\n *\r\n * Software distributed under the License is distributed on an \"AS IS\" basis,\r\n * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License\r\n * for the specific language governing rights and limitations under the\r\n * License.\r\n *\r\n * The Original Code is the JUGJobs project.\r\n *\r\n * The Initial Developers of the Original Code are the members of the Triangle\r\n * Java User's Group in the RTP area of North Carolina.\r\n * Portions created by the Initial Developer are Copyright (C) 2005\r\n * the Initial Developers. All Rights Reserved.\r\n *\r\n * Contributor(s):\r\n *\r\n * ***** END LICENSE BLOCK ***** \r\n");
      out.write(" */\r\n -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      /* ----  html:form ---- */
      org.apache.struts.taglib.html.FormTag _jspx_th_html_form_0 = (org.apache.struts.taglib.html.FormTag) _jspx_tagPool_html_form_action.get(org.apache.struts.taglib.html.FormTag.class);
      _jspx_th_html_form_0.setPageContext(pageContext);
      _jspx_th_html_form_0.setParent(null);
      _jspx_th_html_form_0.setAction("delete.do");
      int _jspx_eval_html_form_0 = _jspx_th_html_form_0.doStartTag();
      if (_jspx_eval_html_form_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n");
          out.write("<table align=\"center\" width=\"450\" cellspacing=\"20\">\r\n");
          out.write("<tr>\r\n  ");
          out.write("<td align=\"center\">\r\n    ");
          /* ----  logic:notPresent ---- */
          org.apache.struts.taglib.logic.NotPresentTag _jspx_th_logic_notPresent_0 = (org.apache.struts.taglib.logic.NotPresentTag) _jspx_tagPool_logic_notPresent_name.get(org.apache.struts.taglib.logic.NotPresentTag.class);
          _jspx_th_logic_notPresent_0.setPageContext(pageContext);
          _jspx_th_logic_notPresent_0.setParent(_jspx_th_html_form_0);
          _jspx_th_logic_notPresent_0.setName("jobBean");
          int _jspx_eval_logic_notPresent_0 = _jspx_th_logic_notPresent_0.doStartTag();
          if (_jspx_eval_logic_notPresent_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n      Sorry.  There has been an error in delete.jsp.");
              out.write("<br>\r\n      You may want to ");
              out.write("\r\n      ");
              JspRuntimeLibrary.include(request, response, "/includes/webmaster.jsp", out, true);
              out.write("<br>\r\n      with the following identifying information.");
              out.write("<br>\r\n      Timestamp:\r\n        ");
              out.print(JobsServlet.instance.logger.log("Missing jobBean in delete.jsp."));
              out.write("\r\n    ");
              int evalDoAfterBody = _jspx_th_logic_notPresent_0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_notPresent_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_notPresent_name.reuse(_jspx_th_logic_notPresent_0);
          out.write("\r\n    \r\n    ");
          /* ----  logic:present ---- */
          org.apache.struts.taglib.logic.PresentTag _jspx_th_logic_present_0 = (org.apache.struts.taglib.logic.PresentTag) _jspx_tagPool_logic_present_name.get(org.apache.struts.taglib.logic.PresentTag.class);
          _jspx_th_logic_present_0.setPageContext(pageContext);
          _jspx_th_logic_present_0.setParent(_jspx_th_html_form_0);
          _jspx_th_logic_present_0.setName("jobBean");
          int _jspx_eval_logic_present_0 = _jspx_th_logic_present_0.doStartTag();
          if (_jspx_eval_logic_present_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("  \r\n      ");
              out.write("<p>\r\n      Really delete job title: \r\n        ");
              if (_jspx_meth_bean_write_0(_jspx_th_logic_present_0, pageContext))
                return;
              out.write(" ?\r\n      ");
              out.write("</p>\r\n      ");
              /* ----  html:submit ---- */
              org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_0 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
              _jspx_th_html_submit_0.setPageContext(pageContext);
              _jspx_th_html_submit_0.setParent(_jspx_th_logic_present_0);
              _jspx_th_html_submit_0.setValue( Constants.DELETE_BUTTON_VALUE);
              _jspx_th_html_submit_0.setProperty("button");
              int _jspx_eval_html_submit_0 = _jspx_th_html_submit_0.doStartTag();
              if (_jspx_th_html_submit_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
                return;
              _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_0);
              out.write("\r\n      ");
              if (_jspx_meth_html_hidden_0(_jspx_th_logic_present_0, pageContext))
                return;
              out.write("\r\n    ");
              int evalDoAfterBody = _jspx_th_logic_present_0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_present_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_present_name.reuse(_jspx_th_logic_present_0);
          out.write("\r\n    ");
          /* ----  html:submit ---- */
          org.apache.struts.taglib.html.SubmitTag _jspx_th_html_submit_1 = (org.apache.struts.taglib.html.SubmitTag) _jspx_tagPool_html_submit_value_property_nobody.get(org.apache.struts.taglib.html.SubmitTag.class);
          _jspx_th_html_submit_1.setPageContext(pageContext);
          _jspx_th_html_submit_1.setParent(_jspx_th_html_form_0);
          _jspx_th_html_submit_1.setValue( Constants.CANCEL_BUTTON_VALUE);
          _jspx_th_html_submit_1.setProperty("button");
          int _jspx_eval_html_submit_1 = _jspx_th_html_submit_1.doStartTag();
          if (_jspx_th_html_submit_1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_html_submit_value_property_nobody.reuse(_jspx_th_html_submit_1);
          out.write("\r\n  ");
          out.write("</td>\r\n");
          out.write("</tr>\r\n");
          out.write("</table>\r\n");
          int evalDoAfterBody = _jspx_th_html_form_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_form_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_html_form_action.reuse(_jspx_th_html_form_0);
      out.write("\r\n\r\n\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }

  private boolean _jspx_meth_bean_write_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  bean:write ---- */
    org.apache.struts.taglib.bean.WriteTag _jspx_th_bean_write_0 = (org.apache.struts.taglib.bean.WriteTag) _jspx_tagPool_bean_write_property_name_nobody.get(org.apache.struts.taglib.bean.WriteTag.class);
    _jspx_th_bean_write_0.setPageContext(pageContext);
    _jspx_th_bean_write_0.setParent(_jspx_th_logic_present_0);
    _jspx_th_bean_write_0.setProperty("job_title");
    _jspx_th_bean_write_0.setName("jobBean");
    int _jspx_eval_bean_write_0 = _jspx_th_bean_write_0.doStartTag();
    if (_jspx_th_bean_write_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_bean_write_property_name_nobody.reuse(_jspx_th_bean_write_0);
    return false;
  }

  private boolean _jspx_meth_html_hidden_0(javax.servlet.jsp.tagext.Tag _jspx_th_logic_present_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
    /* ----  html:hidden ---- */
    org.apache.struts.taglib.html.HiddenTag _jspx_th_html_hidden_0 = (org.apache.struts.taglib.html.HiddenTag) _jspx_tagPool_html_hidden_property_name_nobody.get(org.apache.struts.taglib.html.HiddenTag.class);
    _jspx_th_html_hidden_0.setPageContext(pageContext);
    _jspx_th_html_hidden_0.setParent(_jspx_th_logic_present_0);
    _jspx_th_html_hidden_0.setProperty("job_number");
    _jspx_th_html_hidden_0.setName("jobBean");
    int _jspx_eval_html_hidden_0 = _jspx_th_html_hidden_0.doStartTag();
    if (_jspx_th_html_hidden_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_html_hidden_property_name_nobody.reuse(_jspx_th_html_hidden_0);
    return false;
  }
}

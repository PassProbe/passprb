package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;

public class jobs_jsp extends HttpJspBase {


  private static java.util.Vector _jspx_includes;

  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_html_html;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_empty_scope_name;
  private org.apache.jasper.runtime.TagHandlerPool _jspx_tagPool_logic_notEmpty_scope_name;

  public jobs_jsp() {
    _jspx_tagPool_html_html = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_empty_scope_name = new org.apache.jasper.runtime.TagHandlerPool();
    _jspx_tagPool_logic_notEmpty_scope_name = new org.apache.jasper.runtime.TagHandlerPool();
  }

  public java.util.List getIncludes() {
    return _jspx_includes;
  }

  public void _jspDestroy() {
    _jspx_tagPool_html_html.release();
    _jspx_tagPool_logic_empty_scope_name.release();
    _jspx_tagPool_logic_notEmpty_scope_name.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    javax.servlet.jsp.PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html;charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!--\r\n/* \r\n * JUGJobs -- A Jobs Posting Application for Java Users Groups and Other Groups\r\n * $Id: $\r\n * \r\n * ***** BEGIN LICENSE BLOCK *****\r\n * Version: MPL 1.1\r\n *\r\n * The contents of this file are subject to the Mozilla Public License Version\r\n * 1.1 (the \"License\"); you may not use this file except in compliance with\r\n * the License. You may obtain a copy of the License at\r\n * http://www.mozilla.org/MPL/\r\n *\r\n * Software distributed under the License is distributed on an \"AS IS\" basis,\r\n * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License\r\n * for the specific language governing rights and limitations under the\r\n * License.\r\n *\r\n * The Original Code is the JUGJobs project.\r\n *\r\n * The Initial Developers of the Original Code are the members of the Triangle\r\n * Java User's Group in the RTP area of North Carolina.\r\n * Portions created by the Initial Developer are Copyright (C) 2005\r\n * the Initial Developers. All Rights Reserved.\r\n *\r\n * Contributor(s):\r\n *\r\n * ***** END LICENSE BLOCK ***** \r\n");
      out.write(" */\r\n -->\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n\r\n");
      /* ----  html:html ---- */
      org.apache.struts.taglib.html.HtmlTag _jspx_th_html_html_0 = (org.apache.struts.taglib.html.HtmlTag) _jspx_tagPool_html_html.get(org.apache.struts.taglib.html.HtmlTag.class);
      _jspx_th_html_html_0.setPageContext(pageContext);
      _jspx_th_html_html_0.setParent(null);
      int _jspx_eval_html_html_0 = _jspx_th_html_html_0.doStartTag();
      if (_jspx_eval_html_html_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
        do {
          out.write("\r\n");
          out.write("<head>\r\n  ");
          out.write("<title>Triangle Java Users Group: Jobs");
          out.write("</title>\r\n  ");
          JspRuntimeLibrary.include(request, response, "includes/sniff.jsp", out, true);
          out.write("\r\n");
          out.write("</head>\r\n");
          out.write("<body bgcolor=\"#ffffff\">\r\n\r\n");
          out.write("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n");
          out.write("<tr>\r\n  ");
          out.write("<td valign=\"top\" width=\"170\">\r\n    ");
          out.write("<!-- includes/welcome.jsp CONTAINS WELCOME STUFF  -->\r\n    ");
          JspRuntimeLibrary.include(request, response, "includes/p2logo.jsp", out, true);
          out.write("\r\n    \r\n    ");
          out.write("<!-- includes/nav.jsp CONTAINS LEFT SIDE NAVIGATION  -->\r\n    ");
          JspRuntimeLibrary.include(request, response, "includes/nav.jsp", out, true);
          out.write("\r\n  ");
          out.write("</td>\r\n\r\n  ");
          out.write("<td valign=\"top\" bgcolor=\"#5A5A5A\" rowspan=\"2\" width=\"1\">\r\n    ");
          out.write("<img src=\"images/clear.gif\" width=\"1\" height=\"1\" alt=\"\">\r\n  ");
          out.write("</td>\r\n  ");
          out.write("<td valign=\"top\" width=\"100%\">\r\n    ");
          out.write("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n    ");
          out.write("<tr>\r\n      ");
          out.write("<td valign=\"middle\" width=\"100%\" bgcolor=\"#00309C\" \r\n                            align=\"center\" height=\"15\">\r\n        ");
          out.write("<!-- includes/bar.jsp CONTAINS THE DATE OF THE NEXT PRESENTATION  -->\r\n        ");
          JspRuntimeLibrary.include(request, response, "includes/bar.jsp", out, true);
          out.write("\r\n      ");
          out.write("</td>\r\n    ");
          out.write("</tr>\r\n    ");
          out.write("</table>\r\n    \r\n    ");
          out.write("<!-- Insert body of page here, in a table of width 100% -->\r\n    ");
          if (_jspx_meth_logic_empty_0(_jspx_th_html_html_0, pageContext))
            return;
          out.write("\r\n    ");
          /* ----  logic:notEmpty ---- */
          org.apache.struts.taglib.logic.NotEmptyTag _jspx_th_logic_notEmpty_0 = (org.apache.struts.taglib.logic.NotEmptyTag) _jspx_tagPool_logic_notEmpty_scope_name.get(org.apache.struts.taglib.logic.NotEmptyTag.class);
          _jspx_th_logic_notEmpty_0.setPageContext(pageContext);
          _jspx_th_logic_notEmpty_0.setParent(_jspx_th_html_html_0);
          _jspx_th_logic_notEmpty_0.setScope("request");
          _jspx_th_logic_notEmpty_0.setName("bodyJSP");
          int _jspx_eval_logic_notEmpty_0 = _jspx_th_logic_notEmpty_0.doStartTag();
          if (_jspx_eval_logic_notEmpty_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
            do {
              out.write("\r\n      ");
              JspRuntimeLibrary.include(request, response, (String)request.getAttribute("bodyJSP"), out, true);
              out.write("\r\n    ");
              int evalDoAfterBody = _jspx_th_logic_notEmpty_0.doAfterBody();
              if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
                break;
            } while (true);
          }
          if (_jspx_th_logic_notEmpty_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
            return;
          _jspx_tagPool_logic_notEmpty_scope_name.reuse(_jspx_th_logic_notEmpty_0);
          out.write("\r\n  \r\n  ");
          out.write("</td>\r\n");
          out.write("</tr>\r\n");
          out.write("<tr>\r\n  ");
          out.write("<td valign=\"bottom\">\r\n    ");
          out.write("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" \r\n                                      bgcolor=\"#eeeeee\">\r\n    ");
          out.write("<tr>\r\n      ");
          out.write("<td valign=\"top\" bgcolor=\"#5A5A5A\">\r\n        ");
          out.write("<img src=\"images/clear.gif\" width=\"170\" height=\"1\" alt=\"\">\r\n      ");
          out.write("</td>\r\n    ");
          out.write("</tr>\r\n    ");
          out.write("<tr>\r\n      ");
          out.write("<td valign=\"top\">\r\n        ");
          out.write("<img src=\"images/clear.gif\" width=\"170\" height=\"3\" alt=\"\">\r\n      ");
          out.write("</td>\r\n    ");
          out.write("</tr>  \r\n    ");
          out.write("<!--   email webmaster -->\r\n    ");
          out.write("<tr>\r\n      ");
          out.write("<td valign=\"middle\" align=\"center\" class=\"nav\">\r\n        ");
          JspRuntimeLibrary.include(request, response, "includes/webmaster.jsp", out, true);
          out.write("\r\n      ");
          out.write("</td>\r\n    ");
          out.write("</tr>\r\n    ");
          out.write("<tr>\r\n      ");
          out.write("<td valign=\"top\">\r\n        ");
          out.write("<img src=\"images/clear.gif\" width=\"170\" height=\"3\" alt=\"\">\r\n      ");
          out.write("</td>\r\n    ");
          out.write("</tr>\r\n    ");
          out.write("</table>\r\n  ");
          out.write("</td>\r\n  ");
          out.write("<td valign=\"bottom\" align=\"center\">\r\n    ");
          out.write("<p>[");
          out.write("<a href='./'>Return to Lobby");
          out.write("</a>]");
          out.write("</p>\r\n    ");
          out.write("<br>\r\n  ");
          out.write("</td>\r\n");
          out.write("</tr>\r\n");
          out.write("<tr>\r\n  ");
          out.write("<td valign=\"top\" bgcolor=\"#5A5A5A\" colspan=\"3\">\r\n    ");
          out.write("<img src=\"images/clear.gif\" width=\"1\" height=\"1\">\r\n  ");
          out.write("</td>\r\n");
          out.write("</tr>\r\n\r\n");
          out.write("<!-- includes/footnote.jsp CONTAINS THE LAST UPDATED INFO -->\r\n");
          out.write("<tr>\r\n  ");
          out.write("<td valign=\"top\" align=\"center\" colspan=\"3\">\r\n    ");
          JspRuntimeLibrary.include(request, response, "includes/footnote.jsp", out, true);
          out.write("\r\n  ");
          out.write("</td>\r\n");
          out.write("</tr>\r\n");
          out.write("</table>\r\n\r\n");
          out.write("</body>\r\n");
          int evalDoAfterBody = _jspx_th_html_html_0.doAfterBody();
          if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
            break;
        } while (true);
      }
      if (_jspx_th_html_html_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
        return;
      _jspx_tagPool_html_html.reuse(_jspx_th_html_html_0);
      out.write("\r\n\r\n");
    } catch (Throwable t) {
      out = _jspx_out;
      if (out != null && out.getBufferSize() != 0)
        out.clearBuffer();
      if (pageContext != null) pageContext.handlePageException(t);
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
    }
  }

  private boolean _jspx_meth_logic_empty_0(javax.servlet.jsp.tagext.Tag _jspx_th_html_html_0, javax.servlet.jsp.PageContext pageContext)
          throws Throwable {
    JspWriter out = pageContext.getOut();
HttpServletRequest request = (HttpServletRequest)pageContext.getRequest();
HttpServletResponse response = (HttpServletResponse)pageContext.getResponse();
    /* ----  logic:empty ---- */
    org.apache.struts.taglib.logic.EmptyTag _jspx_th_logic_empty_0 = (org.apache.struts.taglib.logic.EmptyTag) _jspx_tagPool_logic_empty_scope_name.get(org.apache.struts.taglib.logic.EmptyTag.class);
    _jspx_th_logic_empty_0.setPageContext(pageContext);
    _jspx_th_logic_empty_0.setParent(_jspx_th_html_html_0);
    _jspx_th_logic_empty_0.setScope("request");
    _jspx_th_logic_empty_0.setName("bodyJSP");
    int _jspx_eval_logic_empty_0 = _jspx_th_logic_empty_0.doStartTag();
    if (_jspx_eval_logic_empty_0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n    FOO\r\n      ");
        JspRuntimeLibrary.include(request, response, "WEB-INF/pages/jobsTable.jsp", out, true);
        out.write("\r\n    BAR\r\n    ");
        int evalDoAfterBody = _jspx_th_logic_empty_0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_logic_empty_0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE)
      return true;
    _jspx_tagPool_logic_empty_scope_name.reuse(_jspx_th_logic_empty_0);
    return false;
  }
}

import tesina.action.BigliettoAction;
import tesina.action.CompraBigliettoAction;
import tesina.action.ListaSpettacoliAction;
import tesina.action.LoginClientiAction;
import tesina.action.SignupClienteAction;

public class Test {
	public static void main(String[] args) throws Exception {
		BigliettoAction obj = new BigliettoAction();
		obj.execute();
		CompraBigliettoAction obj1 = new CompraBigliettoAction();
		obj1.execute();
		ListaSpettacoliAction obj2 = new ListaSpettacoliAction();
		obj2.execute();
		LoginClientiAction obj3 = new LoginClientiAction();
		obj3.execute();
		SignupClienteAction obj4 = new SignupClienteAction();
		obj4.execute();
	}
}

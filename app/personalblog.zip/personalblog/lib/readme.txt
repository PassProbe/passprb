If you use Mysql you must add the following jar files to this directory (You can take hsqldb.har out if using mysql):


MySQL JDBC driver
